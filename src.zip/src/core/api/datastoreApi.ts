/**
 * Datastore API client — talks to the FastAPI /datastore endpoints.
 *
 * Backend: G:\skiode_lambda_backend\fastapi_service
 * Docs:    https://bzpfusv4ugqui3ysdnx2j53iyy0kefvt.lambda-url.ap-south-1.on.aws/docs
 */

import { useAuthStore } from "../../store/authStore";
import { EMAIL_RULE, hasEmailRule } from "../schema/types";
import { useProjectStore } from "../store/projectStore";
import { PermissionError, extractDetail } from "./permissionError";
import { apiListResources, apiCreateResource, apiCreatePermission } from "./rbacApi";
import { apiFetchMe } from "./authApi";

const API_BASE = import.meta.env.VITE_API_URL || "https://ab2dgab6euwc4d2f3dkgddmxiu0mmuxx.lambda-url.ap-south-1.on.aws";

// Static token injected at build time (e.g. sky-view-builder sets VITE_API_TOKEN in its .env)
const STATIC_TOKEN: string = import.meta.env.VITE_API_TOKEN || "";

/** Resolve auth token: Zustand session first, then build-time env token. */
function resolveToken(): string | null {
  return useAuthStore.getState().token || STATIC_TOKEN || null;
}

// ════════════════════════════════════════════════════════════════════════════
// Backend wire types (match the FastAPI SchemaField Pydantic model)
// ════════════════════════════════════════════════════════════════════════════

export type BackendFieldType = "text" | "number" | "boolean" | "date" | "formattedText";

export interface BackendSchemaField {
  field_id:      string;
  type:          BackendFieldType;
  label:         string;
  value?:        any;              // default value
  cardinality?:  string;           // "list" = multi-value field
  relationKind?: string;           // "integral" | "association"
  relatedDomain?: string;          // the domain this field's relation points to
  relatedDomains?: string[];       // several domains linked by ONE association field — the form shows a domain picker
  validationRefs?: string[];       // attached named validation-rule tags
  // Extended metadata stored via model_config extra: allow
  component?:    string;
  format?:       string;           // "email" marks an email field (stored as text)
  placeholder?:  string;
  datasource?:   string;
  ui_config?:    Record<string, any>;
  rbac?:         Record<string, any>;
  abac?:         Record<string, any>;
  [key: string]: any;              // any extra fields
}

export interface BackendCreateRequest {
  table_name: string;
  schema:     BackendSchemaField[];
  db_backend?: "dynamodb" | "postgresql";
  versioned?: boolean;
  /** Optional — scopes this domain model to a project. If omitted,
   *  apiCreateDomain() below fills it in from the currently-selected
   *  project (see ProjectSelector.tsx / projectStore.ts). Pass an
   *  explicit `null` to force "no project" even if one is selected. */
  project_id?: string | number | null;
  /** Optional — places this domain model in a module of that project
   *  (Project → Module → Domain model). Same defaulting rule as
   *  project_id: omitted → the currently-selected module (only when the
   *  project is also taken from the current selection); explicit `null`
   *  → "no module". */
  module_id?: string | number | null;
}

export interface BackendCreateResponse {
  status:        string;
  table_name:    string;
  table_created?: boolean;   // true = just created, false = already existed
  action?:       string;     // "created" | "already existed"
  db_backend?:   string;     // "dynamodb" | "postgresql"
  aws_region?:   string;     // DynamoDB: e.g. "ap-south-1"
  pg_host?:      string;     // PostgreSQL: host name
  pg_db?:        string;     // PostgreSQL: database name
  total_fields?: number;
  columns?:      { field_id: string; label: string; type: string }[];
  versioned?:    boolean;
  message?:      string;
}

export interface BackendSchemaEntry {
  table_name: string;
  schema:     BackendSchemaField[];
  db_backend?: "dynamodb" | "postgresql";
  versioned?: boolean;
  project_id?: string | null;
  module_id?: string | null;
}

export interface BackendSchemasListResponse {
  status:  string;
  count:   number;
  schemas: BackendSchemaEntry[];
}

export interface BackendSchemaResponse {
  status:     string;
  table_name: string;
  schema:     BackendSchemaField[];
}

export interface BackendRowsResponse {
  status:     string;
  table_name: string;
  count:      number;
  data:       Record<string, any>[];
}

// ════════════════════════════════════════════════════════════════════════════
// Type converters — frontend ↔ backend
// ════════════════════════════════════════════════════════════════════════════

/** Map frontend FieldType → backend field type */
export function frontendTypeToBackend(type: string): BackendFieldType {
  switch (type) {
    case "string":  return "text";
    case "email":   return "text"; // backend has no email type — persisted as text + format:"email"
    case "number":  return "number";
    case "boolean": return "boolean";
    case "date":    return "date";
    default:        return "text";
  }
}

/** Map backend field type → frontend FieldType */
export function backendTypeToFrontend(type: BackendFieldType): string {
  switch (type) {
    case "text":          return "string";
    case "formattedText": return "string";
    case "number":        return "number";
    case "boolean":       return "boolean";
    case "date":          return "date";
    default:              return "string";
  }
}

// ── Resolving named validation registry rules into flat, form-runnable ones ──
// Mirrors flattenNamedValidationRule in src/core/schema/domainBuilder.ts —
// duplicated here (not imported) to keep this API file self-contained. Kept
// in sync manually; if that function's behavior changes, this one should too.

interface FlatValidationRule {
  type: string;
  value?: any;
  message: string;
}

function flattenRegistryRule(rule: any, tag: string): FlatValidationRule[] {
  // Legacy flat shape — already exactly a FlatValidationRule.
  if (rule.type) {
    return [{ type: rule.type, value: rule.value, message: rule.message ?? "" }];
  }

  const desc = rule.description ?? "";

  switch (rule.kind) {
    case "required":
      return [{ type: "required", message: desc || "This field is required" }];
    case "pattern":
      return rule.expression
        ? [{ type: "pattern", value: rule.expression, message: desc || "Invalid format" }]
        : [];
    case "custom":
      return rule.expression
        ? [{ type: "custom", value: rule.expression, message: desc || "Invalid value" }]
        : [];
    case "length": {
      const out: FlatValidationRule[] = [];
      if (rule.min !== undefined) out.push({ type: "minLength", value: rule.min, message: desc || `At least ${rule.min} characters` });
      if (rule.max !== undefined) out.push({ type: "maxLength", value: rule.max, message: desc || `At most ${rule.max} characters` });
      return out;
    }
    case "range": {
      const out: FlatValidationRule[] = [];
      if (rule.min !== undefined) out.push({ type: "min", value: rule.min, message: desc || `Minimum value is ${rule.min}` });
      if (rule.max !== undefined) out.push({ type: "max", value: rule.max, message: desc || `Maximum value is ${rule.max}` });
      return out;
    }
    case "cardinality":
      // Not a scalar-field check — nothing to send to the form runtime for
      // this one, same reasoning as buildSchemas()'s own handling of it.
      console.warn(`[domainToBackendRequest] Skipping "${tag}" (kind: cardinality) — not a field-level check, nothing to enforce client-side.`);
      return [];
    case "all":
      return (rule.validations ?? []).flatMap((sub: any) => flattenRegistryRule(sub, tag));
    default:
      return [];
  }
}

/**
 * Convert a frontend domain definition (all layers) into a backend CreateRequest.
 *
 * The backend's SchemaField uses `model_config = {"extra": "allow"}`, which means
 * we can embed complete ui_config, rbac, abac objects — the backend stores them
 * unchanged and returns them in GET /schemas responses.
 */
export function domainToBackendRequest(params: {
  domainName:  string;
  fields:      Record<string, {
    type:         string;
    default?:     any;
    datasource?:  string;
    validations?: Array<{ type: string; value?: any; message: string }>;
    validationRefs?: string[];
    [key: string]: any;            // allow DomainFieldCore to pass through untyped
  }>;
  uiHints?:    Record<string, Record<string, any>>;   // full-path keys
  rbacRules?:  Record<string, Record<string, any>>;   // full-path keys
  abacRules?:  Record<string, Record<string, any>>;   // full-path keys
  db_backend?: "dynamodb" | "postgresql";              // which DB to store data in
  versioned?:  boolean;                                 // enable version history for this domain
  /** Named validation registry, needed to resolve each field's
   *  validationRefs into real rules before sending — without this, a
   *  field that only has registry refs attached (no inline validations)
   *  would silently persist NO validations at all. */
  registry?: Record<string, any>;
}): BackendCreateRequest {
  const { domainName, fields, uiHints = {}, rbacRules = {}, abacRules = {}, db_backend, versioned, registry = {} } = params;

  const schema: BackendSchemaField[] = Object.entries(fields).map(([fieldName, fieldDef]) => {
    const path = `${domainName}.${fieldName}`;
    const ui   = uiHints[path];
    const rbac = rbacRules[path];
    const abac = abacRules[path];

    const field: BackendSchemaField = {
      field_id: fieldName,
      type:     frontendTypeToBackend(fieldDef.type),
      label:    ui?.label ?? fieldName,
      value:    fieldDef.default ?? null,
    };

    if (fieldDef.datasource)  field.datasource  = fieldDef.datasource;
    // Email fields are stored as text; the format tag is what restores the "email" type on load.
    if (fieldDef.type === "email" || fieldDef.format === "email") field.format = "email";
    if (fieldDef.cardinality) field.cardinality = fieldDef.cardinality;
    if (ui?.component)        field.component   = ui.component;
    if (ui?.placeholder)      field.placeholder = ui.placeholder;

    // Persist the composition/reference distinction for FK columns so
    // consumers (e.g. the view-builder) can tell "part of" relations
    // (branch belongs to clinic — no link/unlink) apart from plain
    // reassignable references (doctor/patient belongs to branch).
    if (fieldDef.relationKind) field.relationKind = fieldDef.relationKind;

    // relatedDomain: the actual target domain a relation points to. Without
    // this, relationKind was saved but the target was silently dropped.
    // This is the save-side counterpart to backendSchemaToFrontend().
    if (fieldDef.relatedDomain) field.relatedDomain = fieldDef.relatedDomain;
    // One association field linking SEVERAL domains: the column stores which
    // one was chosen, and this list is what the form's picker offers.
    if (fieldDef.relatedDomains && fieldDef.relatedDomains.length > 1) field.relatedDomains = fieldDef.relatedDomains;

    // Resolve registry-attached rules (validationRefs) into real, flat
    // rules the Form plugin can run. Inline validations alone were not
    // enough: a tag attached via the Registry Rules chips has to be looked
    // up and resolved here, or it silently vanishes on save.
    const refRules: FlatValidationRule[] = Array.isArray(fieldDef.validationRefs)
      ? fieldDef.validationRefs.flatMap((tag: string) => {
          const rule = registry[tag];
          if (!rule) {
            console.warn(`[domainToBackendRequest] Validation tag "${tag}" not found in registry (field: ${path})`);
            return [];
          }
          return flattenRegistryRule(rule, tag);
        })
      : [];
    const inlineRules: FlatValidationRule[] = Array.isArray(fieldDef.validations) ? fieldDef.validations : [];
    const allValidations = [...refRules, ...inlineRules];
    if (fieldDef.type === "email" && !hasEmailRule(allValidations)) allValidations.push({ ...EMAIL_RULE });
    if (allValidations.length > 0) field.validations = allValidations;

    // Also persist the raw tag list itself (not just the rules resolved
    // from it above) — backendSchemaToFrontend() reads validationRefs
    // back on load to show the tag identity (e.g. "required-name") in the
    // Validation Refs column and the Export tab's JSON.
    if (Array.isArray(fieldDef.validationRefs) && fieldDef.validationRefs.length > 0) {
      field.validationRefs = fieldDef.validationRefs;
    }

    // Store full ui_config blob so it round-trips correctly
    if (ui && Object.keys(ui).length > 0) field.ui_config = ui;
    if (rbac && Object.keys(rbac).length > 0) field.rbac = rbac;
    if (abac && Object.keys(abac).length > 0) field.abac = abac;

    return field;
  });

  const req: BackendCreateRequest = { table_name: domainName, schema };
  if (db_backend) req.db_backend = db_backend;
  if (versioned !== undefined) req.versioned = versioned;
  return req;
}

/**
 * Convert a backend schema response back to a frontend-friendly shape.
 */
export function backendSchemaToFrontend(entry: BackendSchemaEntry): {
  domainName: string;
  fields:     Record<string, {
    type: string; default?: any; datasource?: string;
    cardinality?: string; relationKind?: string;
    relatedDomain?: string; relatedDomains?: string[]; validationRefs?: string[];
  }>;
  uiHints:    Record<string, Record<string, any>>;
  rbacRules:  Record<string, Record<string, any>>;
  abacRules:  Record<string, Record<string, any>>;
  versioned:  boolean;
} {
  const { table_name, schema, versioned } = entry;
  const fields:    Record<string, any> = {};
  const uiHints:   Record<string, any> = {};
  const rbacRules: Record<string, any> = {};
  const abacRules: Record<string, any> = {};

  for (const field of schema) {
    const path = `${table_name}.${field.field_id}`;

    fields[field.field_id] = {
      type:           (field as any).format === "email" ? "email" : backendTypeToFrontend(field.type),
      default:        field.value ?? undefined,
      datasource:     field.datasource,
      cardinality:    field.cardinality ?? undefined,
      relationKind:   field.relationKind ?? undefined,
      // The raw backend field already carries relatedDomain/validationRefs;
      // downstream code (handleLoadFromBackend in SchemaInspector.tsx) reads
      // them off this returned object, so they must be passed through here.
      relatedDomain:  field.relatedDomain ?? undefined,
      relatedDomains: field.relatedDomains ?? undefined,
      validationRefs: field.validationRefs ?? undefined,
    };

    const ui: Record<string, any> = {};
    if (field.component)   ui.component   = field.component;
    if (field.label)       ui.label       = field.label;
    if (field.placeholder) ui.placeholder = field.placeholder;
    if (field.ui_config)   Object.assign(ui, field.ui_config);
    if (Object.keys(ui).length > 0) uiHints[path] = ui;

    if (field.rbac && Object.keys(field.rbac).length > 0) rbacRules[path] = field.rbac;
    if (field.abac && Object.keys(field.abac).length > 0) abacRules[path] = field.abac;
  }

  return { domainName: table_name, fields, uiHints, rbacRules, abacRules, versioned: !!versioned };
}

// ════════════════════════════════════════════════════════════════════════════
// Drafts — a domain model saved in the DB but not yet turned into tables
// ════════════════════════════════════════════════════════════════════════════

/** What the draft will create when it's submitted — one entry per table,
 *  in dependency order (related domains first, then the main domain, then
 *  junction tables). These are the exact same request bodies that would
 *  otherwise have gone straight to POST /datastore/create. */
export interface DraftTableSpec extends BackendCreateRequest {}

export interface SaveDraftRequest {
  domain_name: string;
  project_id?: string | number | null;
  module_id?:  string | number | null;
  tables:      DraftTableSpec[];
  /** Opaque builder state, round-tripped so an unfinished domain reopens
   *  exactly as it was left (the FieldDraft map + the CreateDomainPayload
   *  the UI replays locally once the draft is submitted). */
  fields?:     Record<string, any>;
  payload?:    Record<string, any>;
  db_backend?: "dynamodb" | "postgresql";
  versioned?:  boolean;
}

export interface BackendDraft {
  id:            string;
  domain_name:   string;
  project_id:    string | null;
  module_id?:    string | null;
  status:        "draft" | "submitted";
  payload:       SaveDraftRequest & Record<string, any>;
  created_by:    string | null;
  created_at:    string | null;
  updated_at:    string | null;
  submitted_at:  string | null;
}

export interface BackendDraftListResponse {
  status: string;
  count:  number;
  drafts: BackendDraft[];
}

export interface BackendSubmitDraftResponse {
  status:       string;
  draft_id:     string;
  domain_name?: string;
  submitted_at?: string;
  results?:     { table_name: string; created?: boolean; status: string; message?: string }[];
  message?:     string;
}

export interface BackendValidationRule {
  tag:          string;
  version?:     string;
  description?: string;
  category?:    string;
  kind?:        string;
  type?:        string;
  value?:       any;
  message?:     string;
  expression?:  string;
  min?:         number;
  max?:         number;
  validations?: BackendValidationRule[];
}

export interface BackendValidationRulesListResponse {
  status: string;
  count:  number;
  rules:  BackendValidationRule[];
}

// ════════════════════════════════════════════════════════════════════════════
// API functions
// ════════════════════════════════════════════════════════════════════════════

/**
 * Shared authenticated fetch. EXPORTED so other API modules (e.g.
 * abacApi.ts, rbac APIs) can reuse the exact same auth handling instead
 * of rolling their own raw fetch — a raw fetch without the Authorization
 * header is what produces FastAPI's plain "Not authenticated" response.
 *
 *  - Sends `Authorization: Bearer <token>` when a token is available.
 *  - 401 → logs the user out (session is gone/invalid).
 *  - 403 → throws PermissionError with the backend's `detail` text.
 *  - Any other failure → throws Error("API <status>: <body>").
 */
export async function apiFetch(path: string, init?: RequestInit): Promise<any> {
  const token = resolveToken();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  // Merge caller-supplied headers ON TOP of the defaults instead of letting
  // `...init` replace the whole headers object (which would silently drop
  // the Authorization header whenever a caller passes any headers at all).
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: { ...headers, ...((init?.headers as Record<string, string> | undefined) ?? {}) },
  });
  if (!res.ok) {
    if (res.status === 401) {
      useAuthStore.getState().logout();
    }
    const text = await res.text().catch(() => res.statusText);
    if (res.status === 403) throw new PermissionError(extractDetail(text) || "Permission denied");
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json();
}

/**
 * Project → Module scope used by every call below.
 *  - project omitted (undefined) → use the currently-selected project, and
 *    (if module is also omitted) the currently-selected module.
 *  - project given explicitly   → the selected module is NOT borrowed,
 *    because it belongs to the *selected* project and may not belong to
 *    this one (the backend rejects a project/module mismatch). Pass
 *    `module` explicitly to scope to a module of that project.
 *  - explicit `null` always means "none".
 */
function resolveScope(
  project: string | number | null | undefined,
  module:  string | number | null | undefined,
): { project_id: string | number | null; module_id: string | number | null } {
  const state = useProjectStore.getState();
  const project_id = project !== undefined ? project : state.currentProjectId;
  const module_id =
    module !== undefined ? module
    : project === undefined ? state.currentModuleId
    : null;
  return { project_id, module_id };
}

const DOMAIN_RBAC_ACTIONS = ["create", "view", "edit", "delete"];

/**
 * Make sure a domain model has an RBAC resource (+ create/view/edit/delete
 * actions) so it shows up in Access Control and a role can be granted Delete
 * on it. Best-effort: users who may not manage RBAC (403) are skipped silently.
 * Afterwards the signed-in user's permissions are re-read so a fresh grant
 * shows up without logging out.
 */
export async function ensureDomainRbacResource(domainName: string): Promise<void> {
  if (!domainName) return;
  try {
    const list: any[] = (await apiListResources()).data ?? [];
    const existing = list.find((r) => String(r.name).toLowerCase() === domainName.toLowerCase());
    let id: string | undefined = existing?.id;
    if (!id) {
      const label = domainName.charAt(0).toUpperCase() + domainName.slice(1);
      id = (await apiCreateResource(label, `Domain model: ${domainName}`)).data.id as string;
    }
    let perms: any[] = existing?.permissions ?? [];
    if (typeof perms === "string") { try { perms = JSON.parse(perms); } catch { perms = []; } }
    const have = new Set(perms.map((p) => String(p.action).toLowerCase()));
    for (const action of DOMAIN_RBAC_ACTIONS) if (!have.has(action)) await apiCreatePermission(id!, action);
  } catch { /* not permitted / backend unreachable — an admin can still Sync in RBAC → Resources */ }
  await refreshAuthContext();
}

/** Re-read roles/permissions from /auth/me into the auth store. */
export async function refreshAuthContext(): Promise<void> {
  const { token, setAuthContext } = useAuthStore.getState();
  if (!token) return;
  const ctx = await apiFetchMe(token);
  if (ctx) setAuthContext(ctx);
}


/**
 * POST /datastore/create — create a table from a schema.
 *
 * If `req.project_id` isn't explicitly set, this scopes the new domain
 * model to whichever project is currently selected (ProjectSelector.tsx)
 * — every create-domain call site in SchemaInspector.tsx gets project
 * scoping "for free" this way. Pass `project_id: null` explicitly to
 * force "no project" regardless of what's currently selected.
 */
export async function apiCreateDomain(req: BackendCreateRequest): Promise<BackendCreateResponse> {
  const { project_id, module_id } = resolveScope(req.project_id, req.module_id);

  const res = await apiFetch("/datastore/create", {
    method: "POST",
    body:   JSON.stringify({
      ...req,
      project_id: project_id ?? undefined,
      module_id:  module_id  ?? undefined,
    }),
  });
  // Let the sidebar tree pick up the new domain model.
  useProjectStore.getState().bumpTree();
  // Register it in RBAC so Delete/Edit grants can be given on it.
  await ensureDomainRbacResource(req.table_name);
  return res;
}

/**
 * POST /datastore/drafts — save a domain model as a draft.
 *
 * The draft is persisted in the database, but no tables are created:
 * the backend writes one row to domain_model_drafts and issues no DDL.
 * The tables are generated only by apiSubmitDraft() below. Upserts on
 * (domain_name, project_id), so saving the same domain repeatedly
 * updates its one draft instead of accumulating copies.
 *
 * Project scoping follows the same rule as apiCreateDomain: omit
 * project_id to use the currently-selected project, pass `null` to
 * force "no project".
 */
export async function apiSaveDraft(
  req: SaveDraftRequest,
): Promise<{ status: string; draft_id: string; action?: string; message?: string }> {
  const { project_id, module_id } = resolveScope(req.project_id, req.module_id);

  return apiFetch("/datastore/drafts", {
    method: "POST",
    body:   JSON.stringify({
      ...req,
      project_id: project_id ?? undefined,
      module_id:  module_id  ?? undefined,
    }),
  });
}

/** GET /datastore/drafts — list drafts. `status: "all"` includes already-submitted ones. */
export async function apiListDrafts(
  projectId?: string | null,
  status: "draft" | "submitted" | "all" = "draft",
  moduleId?: string | null,
): Promise<BackendDraftListResponse> {
  const { project_id: effectiveId, module_id: effectiveModule } = resolveScope(projectId, moduleId);

  const params = new URLSearchParams({ status });
  if (effectiveId) params.set("project_id", String(effectiveId));
  if (effectiveModule) params.set("module_id", String(effectiveModule));
  return apiFetch(`/datastore/drafts?${params.toString()}`);
}

/** GET /datastore/drafts/{id} — fetch one draft (to reopen it in the builder) */
export async function apiGetDraft(draftId: string): Promise<{ status: string; draft: BackendDraft }> {
  return apiFetch(`/datastore/drafts/${encodeURIComponent(draftId)}`);
}

/** DELETE /datastore/drafts/{id} — discard a draft */
export async function apiDeleteDraft(draftId: string): Promise<{ status: string; draft_id?: string }> {
  return apiFetch(`/datastore/drafts/${encodeURIComponent(draftId)}`, { method: "DELETE" });
}

/**
 * POST /datastore/drafts/{id}/submit — generate the domain model tables.
 *
 * This is the only call that turns a draft into real tables. If any
 * table fails the backend leaves the draft open (status stays "draft")
 * and reports which ones failed, so it can be fixed and resubmitted.
 */
export async function apiSubmitDraft(draftId: string): Promise<BackendSubmitDraftResponse> {
  const res = await apiFetch(`/datastore/drafts/${encodeURIComponent(draftId)}/submit`, { method: "POST" });
  // Submitting generates real domain models — refresh the sidebar tree.
  useProjectStore.getState().bumpTree();
  const created: any[] = res?.tables ?? res?.created ?? res?.results ?? [];
  for (const t of created) {
    const n = typeof t === "string" ? t : t?.table_name;
    if (n) await ensureDomainRbacResource(n);
  }
  return res;
}

/**
 * GET /datastore/schemas — list registered table schemas.
 * Defaults to the currently-selected project (pass `null` explicitly to
 * force the full unfiltered list regardless of what's selected).
 */
export async function apiListSchemas(
  projectId?: string | null,
  moduleId?: string | null,
): Promise<BackendSchemasListResponse> {
  const { project_id: effectiveId, module_id: effectiveModule } = resolveScope(projectId, moduleId);

  const params = new URLSearchParams();
  if (effectiveId) params.set("project_id", String(effectiveId));
  if (effectiveModule) params.set("module_id", String(effectiveModule));
  const query = params.toString() ? `?${params.toString()}` : "";
  return apiFetch(`/datastore/schemas${query}`);
}

/** GET /datastore/schemas/{table_name} — get schema for one table */
export async function apiGetSchema(tableName: string): Promise<BackendSchemaResponse> {
  return apiFetch(`/datastore/schemas/${tableName}`);
}

/** DELETE /datastore/schemas/{table} — delete a domain model (and by default its table + data) */
export async function apiDeleteDomain(
  tableName: string,
  dropTable = true,
): Promise<{ status: string; table_name?: string }> {
  const res = await apiFetch(
    `/datastore/schemas/${encodeURIComponent(tableName)}?drop_table=${dropTable}`,
    { method: "DELETE" },
  );
  useProjectStore.getState().bumpTree();
  return res;
}

/** PUT /datastore/schemas/{table} — rename a domain model and/or move it to another project/module */
export async function apiUpdateDomain(
  tableName: string,
  body: { new_table_name?: string; project_id?: string | number | null; module_id?: string | number | null },
): Promise<{ status: string; table_name?: string; old_name?: string }> {
  const res = await apiFetch(`/datastore/schemas/${encodeURIComponent(tableName)}`, {
    method: "PUT",
    body:   JSON.stringify(body),
  });
  useProjectStore.getState().bumpTree();
  return res;
}

/** DELETE /datastore/schemas/{table}/fields/{field} — delete one attribute */
export async function apiDeleteField(
  tableName: string,
  fieldId: string,
): Promise<{ status: string }> {
  return apiFetch(
    `/datastore/schemas/${encodeURIComponent(tableName)}/fields/${encodeURIComponent(fieldId)}`,
    { method: "DELETE" },
  );
}

/** PUT /datastore/schemas/{table}/fields/{field} — rename and/or retype one attribute */
export async function apiUpdateField(
  tableName: string,
  fieldId: string,
  body: { new_field_id?: string; type?: BackendFieldType; label?: string },
): Promise<{ status: string; field_id?: string }> {
  return apiFetch(
    `/datastore/schemas/${encodeURIComponent(tableName)}/fields/${encodeURIComponent(fieldId)}`,
    { method: "PUT", body: JSON.stringify(body) },
  );
}

/** POST /datastore/{table_name}/row — insert a data row */
export async function apiInsertRow(
  tableName: string,
  row: Record<string, any>,
): Promise<any> {
  return apiFetch(`/datastore/${tableName}/row`, {
    method: "POST",
    body:   JSON.stringify(row),
  });
}

/** GET /datastore/{table_name}/rows — list all rows */
export async function apiListRows(tableName: string): Promise<BackendRowsResponse> {
  return apiFetch(`/datastore/${tableName}/rows`);
}

/** GET /datastore/{table_name}/row/{id} — get one row by ID */
export async function apiGetRow(tableName: string, recordId: string): Promise<any> {
  return apiFetch(`/datastore/${tableName}/row/${recordId}`);
}

/** POST /datastore/domain-attributes — save a field/attribute for a domain */
export async function apiSaveAttribute(
  domainModelId: string,
  attributeName: string,
  label?: string,
  fieldType?: string,
): Promise<{ status: string; message?: string }> {
  return apiFetch("/datastore/domain-attributes", {
    method: "POST",
    body: JSON.stringify({
      domain_model_id: domainModelId,
      attribute_name:  attributeName,
      label:           label ?? null,
      field_type:      fieldType ?? null,
    }),
  });
}

/** POST /datastore/domain-attributes/{domain}/{attribute}/translation — save one language's label */
export async function apiSaveAttributeTranslation(
  domainModelId: string,
  attributeName: string,
  langCode: "en" | "ta" | "ar",
  label: string,
): Promise<{ status: string; message?: string; label?: string }> {
  return apiFetch(
    `/datastore/domain-attributes/${domainModelId}/${attributeName}/translation`,
    {
      method: "POST",
      body: JSON.stringify({ lang_code: langCode, label }),
    },
  );
}

/** GET /datastore/validation-rules — list every named validation rule stored in the DB */
export async function apiListValidationRules(): Promise<BackendValidationRulesListResponse> {
  return apiFetch("/datastore/validation-rules");
}

/** POST /datastore/validation-rules — create or update (upsert, keyed by tag) one named validation rule */
export async function apiSaveValidationRule(
  tag: string,
  rule: Omit<BackendValidationRule, "tag">,
): Promise<{ status: string; message?: string }> {
  return apiFetch("/datastore/validation-rules", {
    method: "POST",
    body: JSON.stringify({ tag, ...rule }),
  });
}

/** DELETE /datastore/validation-rules/{tag} — now goes through apiFetch so it
 *  sends the Authorization header (the old raw fetch did not). */
export async function apiDeleteValidationRule(tag: string): Promise<{ status: string; message?: string }> {
  return apiFetch(`/datastore/validation-rules/${encodeURIComponent(tag)}`, {
    method: "DELETE",
  });
}