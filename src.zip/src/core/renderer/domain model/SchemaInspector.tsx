import React, { useState, useMemo, useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import type {
  AllSchemas,
  FieldType,
  DomainDefinition,
  DomainFieldCore,
  DomainViewConfig,
  FieldUIConfig,
  NamedValidationRule,
  ABACFieldRule,
  RBACFieldRule,
} from "../../schema/types";
import {
  domainToBackendRequest,
  backendSchemaToFrontend,
  apiCreateDomain,
  apiListSchemas,
  apiDeleteDomain,
  apiDeleteField,
  apiUpdateDomain,
  apiUpdateField,
  frontendTypeToBackend,
  apiSaveAttribute,
  apiSaveAttributeTranslation,
  apiListValidationRules,
  apiSaveValidationRule,
  type BackendSchemaEntry,
  type BackendValidationRule,
} from "../../api/datastoreApi";

import { type ExtraSchemaState, EMPTY_EXTRA, mergeAll } from "./mergeSchemas";
import { dbLocation, buildJunctionDomain, primaryLabel, LANG_ORDER, type JunctionResult } from "./helpers";
import { DomainModelTab } from "./DomainModelTab";
import { UIConfigTab } from "./UIConfigTab";
import { ValidationsTab } from "./ValidationsTab";
import { AccessTab } from "./AccessTab";
import { CreateDomainTab, type CreateDomainPayload } from "./CreateDomainTab";
import { DataTab } from "./DataTab";
import { TranslationsTab } from "./TranslationsTab";
import { ExportJsonTab } from "./ExportJsonTab";
import { applyDomainAccess } from "./accessLoader";
import type { FieldDraft } from "./fieldDraftTypes";
import type { QuickCreateField } from "./DomainPickers";
import { draftToDomainFieldCore, draftToUIHint, draftToABACRule, draftToRBACRule } from "./draftConverters";
import { ImportDomainModelModal } from "./ImportDomainModelModal";
import type { DomainModelImportResult } from "./domainImport";
import { resolveImportScope } from "./importScope";
import { useProjectStore } from "../../store/projectStore";
import type { DomainPermissionRule } from "./Domainpermissionspanel";
import { apiGetDomainAbac, apiSaveDomainAbac, apiListRoleNames } from "../../api/abacapi";

// ════════════════════════════════════════════════════════════════════════════
// Main export — SchemaInspector
// ════════════════════════════════════════════════════════════════════════════

export type MainTab = "domain" | "ui" | "validations" | "access" | "create" | "data" | "tables" | "translations" | "export";

/**
 * Imperative handle so a parent (e.g. App.tsx's page header, next to the
 * "Domain Model Configurator" heading) can trigger the Import JSON modal
 * or jump straight to the Export tab without SchemaInspector needing to
 * lift its tab/modal state up as props. The "Export" tab was removed from
 * the visible tab bar below — this handle is now the only way to reach it,
 * matching the "Import JSON" button which was moved the same way.
 */
export interface SchemaInspectorHandle {
  openImportModal: () => void;
  loadFromBackend: () => void;
}

interface SchemaInspectorProps {
  schemas: AllSchemas;
  /** Sidebar-driven tab, e.g. from App.tsx's own state. When this changes,
   *  the component jumps to that tab — but internal navigation (redirect-
   *  to-create, jump back to "domain" after a successful import, etc.)
   *  still works exactly as before via the internal `tab` state below;
   *  this prop is purely an external "please go here" signal, not a
   *  fully controlled value the parent has to keep in perfect sync with
   *  every internal navigation. */
  activeTab?: MainTab;
  /** Fires whenever the internal tab changes, for any reason (sidebar
   *  click via activeTab above, or internal navigation like "Create
   *  {domain} domain") — so a parent tracking its own state for sidebar
   *  highlighting stays accurate even after an internal-only jump. */
  onTabChange?: (tab: MainTab) => void;
  /** Domain model to scroll to and highlight on the Domain Model tab
   *  (set when one is clicked in the sidebar tree). */
  focusDomain?: string | null;
}

export const SchemaInspector = forwardRef<SchemaInspectorHandle, SchemaInspectorProps>(function SchemaInspector({ schemas, activeTab, onTabChange, focusDomain }, ref) {
  const [tab,   setTab]   = useState<MainTab>(activeTab ?? "domain");
  const [extra, setExtra] = useState<ExtraSchemaState>(EMPTY_EXTRA);
  const [backendLoadStatus, setBackendLoadStatus] = useState<string | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const currentProjectId = useProjectStore((s) => s.currentProjectId);
  const currentModuleId  = useProjectStore((s) => s.currentModuleId);

  // Role names shown in the "Who can access (roles)" dropdown of each
  // domain's Permissions panel. TEMPORARY list — replace with the real
  // roles from the RBAC Admin → Roles page (see the TODO effect below).
  const [availableRoles, setAvailableRoles] = useState<string[]>([]);
  // domainName -> saved access rules (loaded from the backend when a card's Permissions panel opens).
  const [permissions, setPermissions] = useState<Record<string, DomainPermissionRule[]>>({});
  const loadedPermDomains = useRef<Set<string>>(new Set());

  useImperativeHandle(ref, () => ({
    openImportModal: () => setShowImportModal(true),
    loadFromBackend: () => handleLoadFromBackend(),
  }));

  // Sidebar (or any parent) asked to jump to a specific tab.
  useEffect(() => {
    if (activeTab !== undefined && activeTab !== tab) setTab(activeTab);
    // Only reacts to activeTab changing — internal setTab() calls
    // elsewhere in this component must NOT be interrupted by this effect
    // re-firing, so `tab` is deliberately left out of the dependency array.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  // Let the parent know whenever the tab changes, whichever side caused it.
  useEffect(() => {
    onTabChange?.(tab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  // Real role names from the RBAC Roles page (GET /rbac/roles — admin only).
  useEffect(() => {
    apiListRoleNames()
      .then(setAvailableRoles)
      .catch((err) => console.warn("Could not load roles:", err?.message));
  }, []);

  // Load a domain's saved ABAC rules the first time its Permissions panel opens.
  async function handleLoadPermissions(domainName: string) {
    if (loadedPermDomains.current.has(domainName)) return;
    try {
      const rules = await apiGetDomainAbac(domainName);
      loadedPermDomains.current.add(domainName);
      setPermissions((prev) => ({ ...prev, [domainName]: rules }));
    } catch (err: any) {
      flash(`⚠️ Could not load permissions for "${domainName}": ${err?.message ?? String(err)}`, 6000);
    }
  }

  function handleChangePermissions(domainName: string, rules: DomainPermissionRule[]) {
    setPermissions((prev) => ({ ...prev, [domainName]: rules }));
  }

  async function handleSavePermissions(domainName: string, rules: DomainPermissionRule[]) {
    try {
      const saved = await apiSaveDomainAbac(domainName, rules, {
        projectId: extra.projectIds[domainName] ?? currentProjectId,
        moduleId:  extra.moduleIds[domainName]  ?? currentModuleId,
      });
      loadedPermDomains.current.add(domainName);
      setPermissions((prev) => ({ ...prev, [domainName]: saved }));
      flash(`✅ Permissions saved for "${domainName}" (${saved.length} rule${saved.length === 1 ? "" : "s"}).`);
    } catch (err: any) {
      flash(`❌ Could not save permissions for "${domainName}": ${err?.message ?? String(err)}`, 6000);
    }
  }

  const [pendingDomainName, setPendingDomainName] = useState<string | null>(null);
  const [pendingParentDomain, setPendingParentDomain] = useState<string | null>(null);
  const [pendingRelationFieldName, setPendingRelationFieldName] = useState<string | null>(null);
  // Which tab the user was actually on (e.g. "domain") right before a
  // "Create {X} domain" redirect jumped them into the Create Domain tab
  // to build the missing related domain. Once that related domain is
  // created (handleDomainCreated), we jump straight back here instead of
  // stranding the user on the Create Domain tab — that "control never
  // comes back" gap was the reported bug.
  const [returnTab, setReturnTab] = useState<MainTab | null>(null);
  const [pendingFK, setPendingFK] = useState<{
  parentDomain: string;
  childDomain: string;
  fkFieldName: string;
} | null>(null);
  const baseSchemas = useMemo(
    () => ({ ...schemas, domains: {} as typeof schemas.domains }),
    [schemas],
  );

  const liveSchemas = useMemo(() => mergeAll(baseSchemas, extra), [baseSchemas, extra]);
  const liveDomainNames = useMemo(() => Object.keys(liveSchemas.domains), [liveSchemas]);

  // What the Domain Model page's project filter (top-right, App.tsx) should
  // actually show. Backend-sourced domains are already scoped server-side
  // (apiListSchemas' project_id query param) and pruned client-side in
  // handleLoadFromBackend below, but domains created locally and not yet
  // "Saved to Backend" only get their extra.projectIds tag set at creation
  // time (see handleQuickCreateDomain / handleRichCreateDomain /
  // handleDomainCreated) — they still live in liveSchemas.domains
  // regardless of the filter, so filter them here too. "All Projects"
  // (currentProjectId === null) shows everything, matching apiListSchemas()
  // returning the full unfiltered list in that case.
  const visibleSchemas = useMemo(() => {
    if (!currentProjectId && !currentModuleId) return liveSchemas;
    const domains: typeof liveSchemas.domains = {};
    for (const [name, def] of Object.entries(liveSchemas.domains)) {
      const inProject = !currentProjectId || extra.projectIds[name] === currentProjectId;
      // Project → Module → Domain model: when a module is selected, only
      // that module's domain models are visible.
      const inModule  = !currentModuleId  || extra.moduleIds[name]  === currentModuleId;
      if (inProject && inModule) domains[name] = def;
    }
    return { ...liveSchemas, domains };
  }, [liveSchemas, extra.projectIds, extra.moduleIds, currentProjectId, currentModuleId]);

const didAutoLoad = useRef(false);

  // Names of domains that came from the backend on the most recent
  // handleLoadFromBackend() call. Used so that switching the project
  // filter (ProjectFilter in App.tsx → currentProjectId) *replaces* the
  // backend-sourced portion of extra.newDomains instead of merging on
  // top of it — otherwise domains fetched under a previously-selected
  // project lingered forever, since the loop below only ever
  // filters-then-appends by name and never removes anything that isn't
  // in the newest response.
  const lastBackendDomainNames = useRef<Set<string>>(new Set());

  // ── Local persistence for display-only relation markers ───────────────────
  // These are fields like clinic.branch (type: "relation", isPartOf: true)
  // that never become real Postgres columns — the backend has nothing to
  // return for them, so without this they vanish on every reload/HMR.
  const RELATION_MARKERS_KEY = "si_relation_markers";

  function loadRelationMarkers(): Record<string, Record<string, DomainFieldCore>> {
    try {
      const raw = localStorage.getItem(RELATION_MARKERS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  function saveRelationMarker(domainName: string, fieldName: string, field: DomainFieldCore) {
    try {
      const all = loadRelationMarkers();
      all[domainName] = { ...(all[domainName] ?? {}), [fieldName]: field };
      localStorage.setItem(RELATION_MARKERS_KEY, JSON.stringify(all));
    } catch { /* ignore quota errors */ }
  }

  function removeRelationMarker(domainName: string, fieldName: string) {
    try {
      const all = loadRelationMarkers();
      if (all[domainName]) {
        delete all[domainName][fieldName];
        if (Object.keys(all[domainName]).length === 0) delete all[domainName];
        localStorage.setItem(RELATION_MARKERS_KEY, JSON.stringify(all));
      }
    } catch { /* ignore */ }
  }
async function handleQuickCreateDomain(name: string, fields: QuickCreateField[]) {
  const domainFields: Record<string, DomainFieldCore> = {};
  for (const f of fields) { domainFields[f.name] = { type: f.type }; }

  const domainDef: DomainDefinition = { name, fields: domainFields };
    setExtra((prev) => ({
      ...prev,
      newDomains: [...prev.newDomains.filter((d) => d.name !== name), domainDef],
      dbBackends: { ...prev.dbBackends, [name]: "postgresql" },
      // Tag the domain with whichever project is currently selected so the
      // Domain Model page's project filter can hide it once you switch
      // away — otherwise it stays in extra.newDomains untagged forever and
      // shows up under every filter, since apiCreateDomain's own project
      // scoping only takes effect once "Save to Backend" is clicked and a
      // fresh backend reload happens. Left untouched ("no project") when
      // nothing is selected, matching the "All Projects" scope.
      projectIds: currentProjectId
        ? { ...prev.projectIds, [name]: currentProjectId }
        : prev.projectIds,
      moduleIds: currentModuleId
        ? { ...prev.moduleIds, [name]: currentModuleId }
        : prev.moduleIds,
    }));

    // Also create the actual table in the backend
    try {
      const req = domainToBackendRequest({
        registry: liveSchemas._layers?.validationRegistry ?? {},
        domainName: name,
        fields:     domainFields as any,
        uiHints:    {},
        rbacRules:  {},
        abacRules:  {},
        db_backend: "postgresql",
      });
      const res = await apiCreateDomain(req);
      if (res.status === "success") {
        const action = res.table_created ? "created" : "already existed";
        setBackendLoadStatus(`✅ Domain "${name}" ${action} in PostgreSQL.`);
      } else {
        setBackendLoadStatus(`⚠️ Domain "${name}" added to schema, but backend: ${res.message}`);
      }
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Domain "${name}" added to schema but backend unreachable: ${err?.message}`);
    }
    setTimeout(() => setBackendLoadStatus(null), 4000);
  }

  // ── Rich quick-create (LinkDomainModal's embedded compact FieldBuilder) ───
  // Separate from handleQuickCreateDomain above (legacy QuickCreateField[]
  // path, still used by the __new__: JSON-encoded flow elsewhere) — this
  // one receives full FieldDraft objects, so quick-created domains get
  // real labels, relation config, and (if provided) registry validation
  // refs, converted through the same draftToDomainFieldCore / draftToUIHint
  // / draftToRBACRule / draftToABACRule helpers CreateDomainTab.buildPayload
  // uses, instead of being limited to bare {name, type} fields.
  //
  // Scope note: this intentionally only handles (a) plain fields and
  // (b) relation fields pointing at an ALREADY-EXISTING domain (isPartOf
  // === "fk"). It does not attempt junction-table creation for brand-new
  // Association relations, or nested nothing-exists-yet relation chains —
  // those remain the full Create Domain tab's job. The compact
  // FieldBuilder inside the modal already hides the "Create {domain}
  // domain" button (see FieldBuilder's `compact` guard), so a field
  // relating to a domain that doesn't exist yet can't be produced from
  // this path in the first place.
  async function handleRichCreateDomain(
    name: string,
    fieldDrafts: Record<string, FieldDraft>,
    isPartOf: boolean,
    parentDomainName?: string,
  ) {
    const domainFields: Record<string, DomainFieldCore> = {};
    const uiHints: Record<string, FieldUIConfig>        = {};
    const rbacRules: Record<string, RBACFieldRule>      = {};
    const abacRules: Record<string, ABACFieldRule>      = {};
    const fieldLabels: Record<string, Record<"en" | "ta" | "ar", string>> = {};

    for (const [fieldName, d] of Object.entries(fieldDrafts)) {
      fieldLabels[fieldName] = d.labels;

      if (d.type === "relation" && d.relatedDomain && d.isPartOf === "fk") {
        // Belongs-to an existing domain — real FK column on THIS
        // (quick-created) domain, e.g. designation.branchId → branch.
        const fkFieldName = `${d.relatedDomain}Id`;
        domainFields[fkFieldName] = { type: "relation", relatedDomain: d.relatedDomain, relationKind: d.relationKind };
        const fp = `${name}.${fkFieldName}`;
        const hint = draftToUIHint(d);
        uiHints[fp] = Object.keys(hint).length ? hint : { label: primaryLabel(d.labels, fkFieldName) };
        const rbac = draftToRBACRule(d); if (rbac) rbacRules[fp] = rbac;
        const abac = draftToABACRule(d); if (abac) abacRules[fp] = abac;
        continue;
      }

      domainFields[fieldName] = draftToDomainFieldCore(d);
      const fp = `${name}.${fieldName}`;
      const hint = draftToUIHint(d);
      uiHints[fp] = Object.keys(hint).length ? hint : { label: primaryLabel(d.labels, fieldName) };
      const rbac = draftToRBACRule(d); if (rbac) rbacRules[fp] = rbac;
      const abac = draftToABACRule(d); if (abac) abacRules[fp] = abac;
    }

    // Composition — this new domain is "part of" a parent, so it gets the
    // parent's FK column (same convention as pendingFK / handleAddFieldToExisting).
    if (isPartOf && parentDomainName) {
      const parentIdField = `${parentDomainName}Id`;
      if (!domainFields[parentIdField]) {
        domainFields[parentIdField] = { type: "string", relationKind: "integral" };
        uiHints[`${name}.${parentIdField}`] = { label: parentIdField };
      }
    }

    const domainDef: DomainDefinition = { name, fields: domainFields };

    setExtra((prev) => ({
      ...prev,
      newDomains: [...prev.newDomains.filter((d) => d.name !== name), domainDef],
      uiHints:    { ...prev.uiHints,   ...uiHints   },
      rbacRules:  { ...prev.rbacRules, ...rbacRules },
      abacRules:  { ...prev.abacRules, ...abacRules },
      dbBackends: { ...prev.dbBackends, [name]: "postgresql" },
      projectIds: currentProjectId
        ? { ...prev.projectIds, [name]: currentProjectId }
        : prev.projectIds,
      moduleIds: currentModuleId
        ? { ...prev.moduleIds, [name]: currentModuleId }
        : prev.moduleIds,
    }));

    // Persist relation markers (display-only, e.g. a "domain model" typed
    // field whose fkFieldName differs from the literal field name).
    for (const [fieldName, fieldDef] of Object.entries(domainFields)) {
      if (fieldDef.type === "relation" && fieldDef.relatedDomain && fieldName !== `${fieldDef.relatedDomain}Id`) {
        saveRelationMarker(name, fieldName, fieldDef);
      }
    }

    // Push the real table to the backend.
    const backendFields: Record<string, DomainFieldCore> = Object.fromEntries(
      Object.entries(domainFields)
        .filter(([k, f]) => !(f.type === "relation" && f.relatedDomain && k !== `${f.relatedDomain}Id`))
        .map(([k, f]) => [k, f.type === "relation" ? { ...f, type: "string" as FieldType } : f])
    );

    try {
      const req = domainToBackendRequest({
        registry:   liveSchemas._layers?.validationRegistry ?? {},
        domainName: name,
        fields:     backendFields as any,
        uiHints:    uiHints as any,
        rbacRules:  rbacRules as any,
        abacRules:  abacRules as any,
        db_backend: "postgresql",
      } as any);
      const res = await apiCreateDomain(req);
      if (res.status === "success") {
        const action = res.table_created ? "created" : "already existed";
        setBackendLoadStatus(`✅ Domain "${name}" ${action} in ${dbLocation(res)} — ${Object.keys(domainFields).length} field(s).`);
      } else {
        setBackendLoadStatus(`⚠️ Domain "${name}" added to schema, but backend: ${res.message}`);
      }
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Domain "${name}" added to schema but backend unreachable: ${err?.message}`);
    }
    setTimeout(() => setBackendLoadStatus(null), 5000);

    // Save attribute labels/translations, same as handleDomainCreated does
    // for the full Create Domain tab path.
    for (const [fieldName, fieldDef] of Object.entries(domainFields)) {
      const fieldUiHint  = uiHints[`${name}.${fieldName}`];
      const draftLabels  = fieldLabels[fieldName];
      apiSaveAttribute(name, fieldName, fieldUiHint?.label || fieldName, fieldDef.type)
        .then(() => {
          if (!draftLabels) return;
          for (const lang of LANG_ORDER) {
            const text = draftLabels[lang]?.trim();
            if (!text) continue;
            apiSaveAttributeTranslation(name, fieldName, lang, text).catch(console.warn);
          }
        })
        .catch(console.warn);
    }
  }

  // ── Import a full Domain Model JSON (inverse of the Export tab) ────────────
  // Adds every parsed domain's fields into `extra.extraFields` (mergeAll()
  // already knows how to fold that into a brand-new domain OR merge into an
  // existing one), persists relation markers the same way "Link a Domain
  // Model" does, and best-effort creates a real backend table for each
  // domain's non-relation fields (relation fields never become columns —
  // they're display-only markers, same as everywhere else in this file).
  async function handleImportDomainModelJson(result: DomainModelImportResult) {
    // Project → Module structure in the JSON: find or create each project /
    // module first, so every domain can be filed under real ids.
    const scope = await resolveImportScope(result);
    const projectOf = (d: string) => scope.byDomain[d]?.projectId ?? extra.projectIds[d] ?? currentProjectId;
    const moduleOf  = (d: string) => (scope.byDomain[d] ? scope.byDomain[d].moduleId : (extra.moduleIds[d] ?? currentModuleId));

    setExtra((prev) => {
      const nextExtraFields = { ...prev.extraFields };
      const nextDbBackends = { ...prev.dbBackends };
      for (const domain of result.domains) {
        nextExtraFields[domain.name] = { ...(nextExtraFields[domain.name] ?? {}), ...domain.fields };
        if (!nextDbBackends[domain.name]) nextDbBackends[domain.name] = "postgresql";
      }
      // Tag imported domains with their project/module (from the JSON's
      // structure, else the currently selected one) — otherwise the
      // project/module filter (visibleSchemas) hides them.
      const nextProjectIds = { ...prev.projectIds };
      const nextModuleIds  = { ...prev.moduleIds };
      for (const { name } of result.domains) {
        const scoped = scope.byDomain[name];
        const pid = scoped ? scoped.projectId : currentProjectId;
        const mid = scoped ? scoped.moduleId  : currentModuleId;
        if (pid) nextProjectIds[name] = pid;
        if (mid) nextModuleIds[name] = mid; else if (scoped) delete nextModuleIds[name];
      }
      return {
        ...prev,
        extraFields: nextExtraFields,
        dbBackends: nextDbBackends,
        // Inline `access.rbac` / `access.abac` from the imported JSON.
        rbacRules:  { ...prev.rbacRules, ...result.rbacRules },
        abacRules:  { ...prev.abacRules, ...result.abacRules },
        projectIds: nextProjectIds,
        moduleIds:  nextModuleIds,
      };
    });

    for (const [domName, markers] of Object.entries(result.relationMarkers)) {
      for (const [fieldName, fieldDef] of Object.entries(markers)) {
        saveRelationMarker(domName, fieldName, fieldDef);
      }
    }

    setTab("domain");
    setShowImportModal(false);

    let created = 0;
    let failed = 0;
    for (const domain of result.domains) {
      // Display-only relation markers (parent-side integral links and
      // associations) never become columns, but a child's real FK does —
      // send it as a plain string column, like everywhere else in this file.
      const backendFields = Object.fromEntries(
        Object.entries(domain.fields)
          .filter(([, f]) => f.type !== "relation" || (f.relationKind === "integral" && f.cardinality !== "list" && !!f.relatedDomain))
          .map(([k, f]) => [k, f.type === "relation" ? { ...f, type: "string" as FieldType } : f])
      );
      if (Object.keys(backendFields).length === 0) continue;
      try {
        const req = domainToBackendRequest({
          registry:   liveSchemas._layers?.validationRegistry ?? {},
          domainName: domain.name,
          fields:     backendFields as any,
          uiHints:    {},
          rbacRules:  result.rbacRules,
          abacRules:  result.abacRules,
          db_backend: "postgresql",
        });
        // Domains nested under a project / module in the JSON are created
        // there explicitly (null module = "in the project, no module");
        // the rest fall back to the currently selected scope as before.
        if (scope.byDomain[domain.name]) {
          req.project_id = scope.byDomain[domain.name].projectId;
          req.module_id  = scope.byDomain[domain.name].moduleId;
        }
        const res = await apiCreateDomain(req);
        if (res.status === "success") created++; else failed++;
      } catch {
        failed++;
      }
    }
    // Association links → junction tables.
    for (const { a, b } of result.associations) {
      await ensureJunctionDomain(a, b, "postgresql");
    }
    // Domain-level access (`access.rbac` role → actions, `access.abac` rules).
    let accessNote = "";
    if (Object.keys(result.domainAccess).length > 0) {
      const acc = await applyDomainAccess(result.domainAccess, (d) => ({
        projectId: projectOf(d),
        moduleId:  moduleOf(d),
      }));
      accessNote = ` — access: ${acc.rbacRoles} role grant set(s), ${acc.abacDomains} ABAC domain(s)` +
        (acc.warnings.length ? ` (${acc.warnings.length} warning(s): ${acc.warnings[0]})` : "");
    }
    const scopeNote = result.projects.length
      ? ` in ${result.totalProjects} project(s) / ${result.totalModules} module(s)` +
        (scope.createdProjects || scope.createdModules ? ` (created ${scope.createdProjects} project(s), ${scope.createdModules} module(s))` : "") +
        (scope.warnings.length ? ` — ⚠️ ${scope.warnings[0]}` : "")
      : "";
    useProjectStore.getState().bumpTree();
    setBackendLoadStatus(
      `✅ Imported ${result.totalDomains} domain model(s)${scopeNote}, ${result.totalAttributes} attribute(s)` +
      (result.skippedSynthesized ? ` (${result.skippedSynthesized} synthesized attribute(s) skipped)` : "") +
      (failed ? ` — ${created} table(s) saved to backend, ${failed} failed (still available locally).` : ` — saved to backend.`) +
      accessNote
    );
    setTimeout(() => setBackendLoadStatus(null), 6000);
  }

  // ── Redirect to Create Domain tab ─────────────────────────────────────────
const handleRedirectToCreate = (domainName: string, parentDomain?: string, fieldName?: string) => {
  // Remember where we're jumping FROM so handleDomainCreated can send the
  // user straight back once the related domain is created. Only capture
  // it the first time (don't overwrite with "create" if a second redirect
  // happens while one is already pending) so nested "create X, which
  // needs Y, which needs Z" chains still land back on the original tab.
  setReturnTab((prev) => prev ?? (tab !== "create" ? tab : prev));
  setPendingDomainName(domainName);
  setPendingParentDomain(parentDomain || null);
  setPendingRelationFieldName(fieldName || null);
  // ✅ Ensure the parent's FK column gets injected into the new child
  // domain's fields when it's created, same as the handleAddFieldToExisting
  // path does. Without this, clicking "Create {domain} domain" straight
  // from the FieldBuilder button skips FK wiring entirely.
  if (parentDomain) {
    setPendingFK({
      parentDomain,
      childDomain: domainName,
      fkFieldName: `${parentDomain}Id`,
    });
  }
  setTab("create");
};
  // ── Core junction creation helper ─────────────────────────────────────────
async function ensureJunctionDomain(
  parentDomainName: string,
  relatedDomainName: string,
  dbBackend: string,
  cardinality?: string,
): Promise<JunctionResult> {
  const pairKey = [parentDomainName, relatedDomainName].sort().join("__");
  const junctionName = `${parentDomainName}_${relatedDomainName}`;
  if (extra.junctionPairs.has(pairKey)) return { name: junctionName, status: "skipped" }; // ✅ deduplicate

  // The same pair may already exist under the reverse name (B_A when we'd
  // create A_B) — e.g. after a reload, when junctionPairs is empty again.
  // Only treat it as that junction if it is exactly the two FK columns.
  const reverseName   = `${relatedDomainName}_${parentDomainName}`;
  const reverseFields = Object.keys(liveSchemas.domains[reverseName]?.fields ?? {}).sort().join(",");
  const expectedPair  = [`${parentDomainName}Id`, `${relatedDomainName}Id`].sort().join(",");
  if (reverseFields && reverseFields === expectedPair) {
    return { name: reverseName, status: "exists", message: `"${reverseName}" already links these two domains` };
  }

  const jd = buildJunctionDomain(parentDomainName, relatedDomainName, cardinality);

  // Always build rd with parent fields
  // If cbranch was quick-created with empty fields, use parent fields
  // If cbranch already has its own fields, keep those
  const parentFields = liveSchemas.domains[parentDomainName]?.fields ?? {};
  const relatedExistingFields = liveSchemas.domains[relatedDomainName]?.fields ?? {};
  const hasExistingFields = Object.keys(relatedExistingFields).length > 0;

const rd: DomainDefinition = {
    name:   relatedDomainName,
    fields: hasExistingFields
      ? { ...relatedExistingFields } as Record<string, DomainFieldCore>
      : {} as Record<string, DomainFieldCore>,
  };
  // Always add both rd and jd to live schema
setExtra((prev) => {
    const nextPairs = new Set(prev.junctionPairs);
    nextPairs.add(pairKey);
    const toAdd = [jd]; // junction only — no parent ID in either table
    return {
      ...prev,
      newDomains: [
        ...prev.newDomains.filter((d) => !toAdd.find((n) => n.name === d.name)),
        ...toAdd,
      ],
      dbBackends: {
        ...prev.dbBackends,
        ...Object.fromEntries(toAdd.map((d) => [d.name, dbBackend])),
      },
      projectIds: currentProjectId
        ? { ...prev.projectIds, ...Object.fromEntries(toAdd.map((d) => [d.name, currentProjectId])) }
        : prev.projectIds,
      moduleIds: currentModuleId
        ? { ...prev.moduleIds, ...Object.fromEntries(toAdd.map((d) => [d.name, currentModuleId])) }
        : prev.moduleIds,
      junctionPairs: nextPairs,
    };
  });

  // Always push both rd and jd to backend
  // apiCreateDomain returns table_created: false if already exists — safe to call always
const domainsToPush = [jd];
  let result: JunctionResult = { name: jd.name, status: "failed" };
  for (const domain of domainsToPush) {
    const isJunction = true;
    try {
      const req = domainToBackendRequest({
        registry: liveSchemas._layers?.validationRegistry ?? {},
        domainName: domain.name,
        fields:     domain.fields as any,
        uiHints:    {},
        rbacRules:  {},
        abacRules:  {},
        db_backend: dbBackend as any,
      });
      const res = await apiCreateDomain(req);
      if (res.status === "success") {
        const action = res.table_created ? "created" : "already existed";
        const label  = isJunction ? "Junction table" : "Related domain";
        setBackendLoadStatus(`✅ ${label} "${domain.name}" ${action}.`);
        result = { name: domain.name, status: res.table_created ? "created" : "exists" };
      } else {
        setBackendLoadStatus(`⚠️ "${domain.name}" added to schema, but backend: ${res.message}`);
        result = { name: domain.name, status: "failed", message: res.message };
      }
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ "${domain.name}" backend unreachable: ${err?.message}`);
      result = { name: domain.name, status: "failed", message: err?.message };
    }
  }
  setTimeout(() => setBackendLoadStatus(null), 5000);
  return result;
}

/**
 * One association field can link several domains (draft.relatedDomains).
 * Creates a `${domainName}_${related}` junction table for EACH of them, in
 * order, and — when there is more than one — replaces the per-table toasts
 * with a single combined summary (which names any that failed).
 */
async function ensureJunctionsFor(
  domainName: string,
  draft: FieldDraft,
  dbBackend: string,
): Promise<JunctionResult[]> {
  const targets = Array.from(new Set(
    (draft.relatedDomains?.length ? draft.relatedDomains : [draft.relatedDomain]).filter(Boolean),
  ));
  const results: JunctionResult[] = [];
  for (const related of targets) {
    results.push(await ensureJunctionDomain(domainName, related, dbBackend, draft.cardinality || undefined));
  }
  if (targets.length > 1) {
    const failed  = results.filter((r) => r.status === "failed");
    const created = results.filter((r) => r.status === "created").map((r) => r.name);
    setBackendLoadStatus(
      failed.length
        ? `⚠️ Linked ${targets.length} domains to "${domainName}" — ${results.length - failed.length} junction table(s) ready, ` +
          `${failed.length} failed: ${failed.map((f) => `${f.name}${f.message ? ` (${f.message})` : ""}`).join(", ")}`
        : `✅ Linked ${targets.length} domains to "${domainName}" — ` +
          (created.length ? `created ${created.length} junction table(s): ${created.join(", ")}` : "junction tables already existed") +
          (created.length && created.length < results.length ? ` (${results.length - created.length} already existed)` : ""),
    );
    setTimeout(() => setBackendLoadStatus(null), 7000);
  }
  return results;
}

  // ── Handlers ──────────────────────────────────────────────────────────────

  /** Adds the real `fieldName` text column (domain-choice column) to `domainName`'s table. */
  async function addDomainChoiceColumn(
    domainName: string, fieldName: string, draft: FieldDraft,
    uiHint: ReturnType<typeof draftToUIHint>, fullPath: string,
  ) {
    try {
      const existingFields = liveSchemas.domains[domainName]?.fields ?? {};
      const req = domainToBackendRequest({
        registry: liveSchemas._layers?.validationRegistry ?? {},
        domainName,
        fields: {
          ...existingFields,
          [fieldName]: {
            type: "string" as FieldType,
            relationKind: "association",
            relatedDomain: draft.relatedDomain,
            relatedDomains: draft.relatedDomains,
          },
        } as any,
        uiHints: { ...(liveSchemas.uiHints as any), [fullPath]: { ...uiHint, label: primaryLabel(draft.labels, fieldName) } },
        rbacRules: extra.rbacRules as any, abacRules: extra.abacRules as any,
      });
      const res = await apiCreateDomain(req);
      setBackendLoadStatus(
        res.status === "success"
          ? `✅ Column "${fieldName}" added to "${domainName}" — stores the chosen one of ${draft.relatedDomains!.join(", ")}.`
          : `⚠️ "${fieldName}" added locally, but backend: ${res.message}`,
      );
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Could not add column "${fieldName}" to "${domainName}": ${err?.message}`);
    }
  }

  async function handleAddFieldToExisting(domainName: string, fieldName: string, draft: FieldDraft): Promise<JunctionResult | undefined> {
    console.log("handleAddFieldToExisting called — type:", draft.type, "isPartOf:", draft.isPartOf, "relatedDomain:", draft.relatedDomain);
    const fullPath = `${domainName}.${fieldName}`;
    const uiHint   = draftToUIHint(draft);
    const abac     = draftToABACRule(draft);
    const rbac     = draftToRBACRule(draft);
    const newField = draftToDomainFieldCore(draft);

setExtra((prev) => ({
      ...prev,
      // Belongs-to FK relations (isPartOf === "fk") skip adding the literal
      // field name here — the real fkFieldName (e.g. patientId) is added by
      // the dedicated "fk" branch below instead, so we don't want a
      // duplicate "patient" field sitting next to "patientId".
      // New parent→child relations (isPartOf === true) DO get added here —
      // for relations this is a display-only marker in the parent's field
      // list (it's never sent to the backend as a real column; the child
      // domain gets the real FK, handled further below).
      extraFields: (draft.type === "relation" && draft.isPartOf === "fk")
        ? prev.extraFields
        : { ...prev.extraFields, [domainName]: { ...(prev.extraFields[domainName] ?? {}), [fieldName]: newField } },
      uiHints:     Object.values(uiHint).some((v) => v !== undefined) ? { ...prev.uiHints, [fullPath]: uiHint } : prev.uiHints,
      abacRules:   abac ? { ...prev.abacRules, [fullPath]: abac } : prev.abacRules,
      rbacRules:   rbac ? { ...prev.rbacRules, [fullPath]: rbac } : prev.rbacRules,
    }));
    try {
      await apiSaveAttribute(domainName, fieldName, primaryLabel(draft.labels, fieldName), draft.type);
      for (const lang of LANG_ORDER) {
        const text = draft.labels[lang]?.trim();
        if (!text) continue;
        await apiSaveAttributeTranslation(domainName, fieldName, lang, text);
      }
    } catch (err: any) {
      console.warn("Could not save attribute/translations:", err?.message);
    }

    // Auto-create junction table if this is a relation field
if (draft.type === "relation" && draft.relatedDomain && !draft.relatedDomain.startsWith("__new__:")) {
      const dbBackend = extra.dbBackends[domainName] ?? "postgresql";
console.log("handleAddFieldToExisting — isPartOf:", draft.isPartOf, "domain:", domainName, "related:", draft.relatedDomain);

if (draft.isPartOf === "fk") {
        // ✅ Belongs-to — existing domain, no junction/no modal. THIS domain
        // (the one being edited, e.g. consultation) gets a real FK column,
        // e.g. consultation.patientId → patient. The related domain is left
        // untouched.
        const fkFieldName = `${draft.relatedDomain}Id`;
        // Keep type "relation" locally so the UI still shows the 🔗 badge and
        // renders a domain-picker in the Data tab; the physical DB column is
        // sent as "string", matching how FK columns are persisted elsewhere.
        const fkFieldLocal: DomainFieldCore = { type: "relation", relatedDomain: draft.relatedDomain, relationKind: draft.relationKind };
        setExtra((prev) => ({
          ...prev,
          extraFields: {
            ...prev.extraFields,
            [domainName]: {
              ...(prev.extraFields[domainName] ?? {}),
              [fkFieldName]: fkFieldLocal,
            },
          },
        }));
        try {
          const existingFields = liveSchemas.domains[domainName]?.fields ?? {};
          const updatedFields = {
            ...existingFields,
            // relationKind: "association" marks this as a reassignable
            // belongs-to FK (e.g. doctor.branchId → branch), so the
            // view-builder shows Add Existing / Remove actions for it.
            [fkFieldName]: { type: "string" as FieldType, relationKind: draft.relationKind },
          };
          const req = domainToBackendRequest({
            registry: liveSchemas._layers?.validationRegistry ?? {},
            domainName, fields: updatedFields as any, uiHints: liveSchemas.uiHints as any,
            rbacRules: extra.rbacRules as any, abacRules: extra.abacRules as any,
          });
          const res = await apiCreateDomain(req);
          if (res.status === "success") {
            setBackendLoadStatus(
              `✅ "${fkFieldName}" added to "${domainName}" — FK → "${draft.relatedDomain}" in ${dbLocation(res)}.`
            );
          } else {
            setBackendLoadStatus(`⚠️ "${fkFieldName}" added locally, but backend: ${res.message}`);
          }
        } catch (err: any) {
          setBackendLoadStatus(`⚠️ Could not add "${fkFieldName}" to "${domainName}": ${err?.message}`);
        }
        setTimeout(() => setBackendLoadStatus(null), 5000);
     } else if (!draft.isPartOf) {
        // 🔀 Association — create the junction table (no column on either side).
        saveRelationMarker(domainName, fieldName, newField);
        const junctions = await ensureJunctionsFor(domainName, draft, dbBackend);
        // Several domains linked by ONE field → the parent table also gets a
        // real text column (named after the field) that stores WHICH domain
        // the user picked; the picked record itself is linked through that
        // domain's junction table. The form uses relatedDomains to offer the
        // domain picker.
        if ((draft.relatedDomains?.length ?? 0) > 1) {
          await addDomainChoiceColumn(domainName, fieldName, draft, uiHint, fullPath);
        }
        setTimeout(() => setBackendLoadStatus(null), 5000);
        return junctions[0];
     } else if (draft.isPartOf) {
        // ✅ CHECKED — add parentId FK into child (relatedDomain) table
        const parentIdField = `${domainName}Id`;
        // Persist the display-only marker on THIS (parent) domain so it
        // survives a reload — the backend never sees a real "branch" column.
        saveRelationMarker(domainName, fieldName, newField);
        
        // 🔥 FIX: Check if child domain already exists
        const childExists = liveSchemas.domains[draft.relatedDomain] !== undefined;
        
        if (childExists) {
          // Child exists — add FK via API call
          setExtra((prev) => ({
            ...prev,
            extraFields: {
              ...prev.extraFields,
              [draft.relatedDomain]: {
                ...(prev.extraFields[draft.relatedDomain] ?? {}),
                [parentIdField]: { type: "string", relationKind: "integral", cardinality: (draft.cardinality as any) || undefined },
              },
            },
          }));
          try {
            const childExistingFields = liveSchemas.domains[draft.relatedDomain]?.fields ?? {};
            const childUpdatedFields = {
              ...childExistingFields,
              // relationKind: "integral" marks this as a composition FK
              // (e.g. branch.clinicId → clinic) — the child only ever
              // exists under its parent, so the view-builder hides
              // Add Existing / Remove for it and only allows Create.
              [parentIdField]: { type: "string" as FieldType, relationKind: "integral", cardinality: (draft.cardinality as any) || undefined },
            };
            const req = domainToBackendRequest({
              registry: liveSchemas._layers?.validationRegistry ?? {},
              domainName:  draft.relatedDomain,
              fields:      childUpdatedFields as any,
              uiHints:     {},
              rbacRules:   {},
              abacRules:   {},
              db_backend:  dbBackend as any,
            });
            const res = await apiCreateDomain(req);
            if (res.status === "success") {
              setBackendLoadStatus(
                `✅ "${parentIdField}" added to child table "${draft.relatedDomain}" — ${dbLocation(res)}`
              );
            } else {
              setBackendLoadStatus(`⚠️ "${parentIdField}" to "${draft.relatedDomain}": ${res.message}`);
            }
          } catch (err: any) {
            setBackendLoadStatus(`⚠️ Could not add "${parentIdField}" to "${draft.relatedDomain}": ${err?.message}`);
          }
        } else {
          // 🔥 NEW: Child doesn't exist yet — set pending FK to be added during domain creation
          setPendingFK({
            parentDomain: domainName,
            childDomain: draft.relatedDomain,
            fkFieldName: parentIdField,
          });
          // Redirect to create the child domain
          handleRedirectToCreate?.(draft.relatedDomain, domainName, fieldName);
        }
        setTimeout(() => setBackendLoadStatus(null), 5000);
      }
    }
  }

  async function handleEditField(domainName: string, oldName: string, newName: string, draft: FieldDraft) {
    const updatedField = draftToDomainFieldCore(draft);
    const uiHint       = draftToUIHint(draft);
    const abac         = draftToABACRule(draft);
    const rbac         = draftToRBACRule(draft);
    const oldPath      = `${domainName}.${oldName}`;
    const newPath      = `${domainName}.${newName}`;
    const isRename     = oldName !== newName;

    const domainInNewDomains = extra.newDomains.find((d) => d.name === domainName);

    setExtra((prev) => {
      const uiHints = { ...prev.uiHints };
      if (isRename && uiHints[oldPath]) { uiHints[newPath] = uiHints[oldPath]; delete uiHints[oldPath]; }
      if (Object.values(uiHint).some((v) => v !== undefined)) uiHints[newPath] = uiHint;

      const abacRules = { ...prev.abacRules };
      if (isRename && abacRules[oldPath]) { abacRules[newPath] = abacRules[oldPath]; delete abacRules[oldPath]; }
      if (abac) abacRules[newPath] = abac;

      const rbacRules = { ...prev.rbacRules };
      if (isRename && rbacRules[oldPath]) { rbacRules[newPath] = rbacRules[oldPath]; delete rbacRules[oldPath]; }
      if (rbac) rbacRules[newPath] = rbac;

      if (prev.newDomains.some((d) => d.name === domainName)) {
        const updatedNewDomains = prev.newDomains.map((d) => {
          if (d.name !== domainName) return d;
          const fields = { ...d.fields };
          if (isRename) delete fields[oldName];
          // ✅ relation fields never become columns in the parent domain
          if ((draft.type as string) === "relation") {
            delete fields[newName];
          } else {
            fields[newName] = updatedField;
          }
          return { ...d, fields };
        });
        const domainExtraFields = { ...(prev.extraFields[domainName] ?? {}) };
        if (isRename) delete domainExtraFields[oldName];
        delete domainExtraFields[newName];
        return { ...prev, newDomains: updatedNewDomains, extraFields: { ...prev.extraFields, [domainName]: domainExtraFields }, uiHints, abacRules, rbacRules };
      } else {
        const domainFields = { ...(prev.extraFields[domainName] ?? {}) };
        if (isRename) delete domainFields[oldName];
        // ✅ relation fields never become columns in the parent domain
        if ((draft.type as string) === "relation") {
          delete domainFields[newName];
        } else {
          domainFields[newName] = updatedField;
        }
        return { ...prev, extraFields: { ...prev.extraFields, [domainName]: domainFields }, uiHints, abacRules, rbacRules };
      }
    });

try {
      await apiSaveAttribute(domainName, newName, primaryLabel(draft.labels, newName), draft.type);
      for (const lang of LANG_ORDER) {
        const text = draft.labels[lang]?.trim();
        if (!text) continue;
        await apiSaveAttributeTranslation(domainName, newName, lang, text);
      }
    } catch (err: any) {
      console.warn("Could not save attribute/translations:", err?.message);
    }

if (draft.type === "relation" && draft.relatedDomain && !draft.relatedDomain.startsWith("__new__:")) {
      const dbBackend = extra.dbBackends[domainName] ?? "postgresql";
      console.log("HANDLER isPartOf:", draft.isPartOf, "relatedDomain:", draft.relatedDomain);

if (draft.isPartOf === "fk") {
        // ✅ Belongs-to — existing domain. THIS domain gets a real FK column,
        // e.g. consultation.patientId → patient. No junction table.
        const fkFieldName = `${draft.relatedDomain}Id`;
        const fkFieldLocal: DomainFieldCore = { type: "relation", relatedDomain: draft.relatedDomain, relationKind: draft.relationKind };
        setExtra((prev) => ({
          ...prev,
          extraFields: {
            ...prev.extraFields,
            [domainName]: {
              ...(prev.extraFields[domainName] ?? {}),
              [fkFieldName]: fkFieldLocal,
            },
          },
        }));
        try {
          const existingFields = liveSchemas.domains[domainName]?.fields ?? {};
          const updatedFields = {
            ...existingFields,
            // relationKind: "association" marks this as a reassignable
            // belongs-to FK (e.g. doctor.branchId → branch), so the
            // view-builder shows Add Existing / Remove actions for it.
            [fkFieldName]: { type: "string" as FieldType, relationKind: draft.relationKind },
          };
          const req = domainToBackendRequest({
            registry: liveSchemas._layers?.validationRegistry ?? {},
            domainName, fields: updatedFields as any, uiHints: liveSchemas.uiHints as any,
            rbacRules: extra.rbacRules as any, abacRules: extra.abacRules as any,
          });
          const res = await apiCreateDomain(req);
          if (res.status === "success") {
            setBackendLoadStatus(
              `✅ "${fkFieldName}" added to "${domainName}" — FK → "${draft.relatedDomain}" in ${dbLocation(res)}.`
            );
          } else {
            setBackendLoadStatus(`⚠️ "${fkFieldName}" added locally, but backend: ${res.message}`);
          }
        } catch (err: any) {
          setBackendLoadStatus(`⚠️ Could not add "${fkFieldName}" to "${domainName}": ${err?.message}`);
        }
        setTimeout(() => setBackendLoadStatus(null), 5000);
      } else if (!draft.isPartOf) {
        // ❌ UNCHECKED — create junction table(s)
        await ensureJunctionsFor(domainName, draft, dbBackend);
      } else {
        // ✅ CHECKED — add domainNameId into child (relatedDomain) table only
        const parentIdField = `${domainName}Id`;
        setExtra((prev) => ({
          ...prev,
          extraFields: {
            ...prev.extraFields,
            [draft.relatedDomain]: {
              ...(prev.extraFields[draft.relatedDomain] ?? {}),
              [parentIdField]: { type: "string", relationKind: "integral", cardinality: (draft.cardinality as any) || undefined },
            },
          },
        }));
        try {
          const childExistingFields = liveSchemas.domains[draft.relatedDomain]?.fields ?? {};
          const childUpdatedFields  = {
            ...childExistingFields,
            // relationKind: "integral" marks this as a composition FK
            // (e.g. branch.clinicId → clinic) — the child only ever
            // exists under its parent, so the view-builder hides
            // Add Existing / Remove for it and only allows Create.
            [parentIdField]: { type: "string" as FieldType, relationKind: "integral", cardinality: (draft.cardinality as any) || undefined },
          };
          const req = domainToBackendRequest({
            registry: liveSchemas._layers?.validationRegistry ?? {},
            domainName:  draft.relatedDomain,
            fields:      childUpdatedFields as any,
            uiHints:     {},
            rbacRules:   {},
            abacRules:   {},
            db_backend:  dbBackend as any,
          });
          const res = await apiCreateDomain(req);
          if (res.status === "success") {
            setBackendLoadStatus(
              `✅ "${parentIdField}" added to "${draft.relatedDomain}" — ${dbLocation(res)}.`
            );
          } else {
            setBackendLoadStatus(`⚠️ "${parentIdField}" added locally, backend: ${res.message}`);
          }
        } catch (err: any) {
          setBackendLoadStatus(`⚠️ Could not add "${parentIdField}" to backend: ${err?.message}`);
        }
        setTimeout(() => setBackendLoadStatus(null), 5000);

      } 
    }

    // Relation fields are fully handled by the branches above — each one
    // (fk / checked parent→child / unchecked junction) already sent its
    // own complete apiCreateDomain request with the correct field shape
    // (including relationKind). Running this generic trailing save for
    // relation fields too was a real bug: it read from `extra.extraFields`,
    // a React state snapshot that doesn't yet reflect the setExtra call
    // just made above (state updates aren't synchronous), so it would send
    // a stale/incomplete payload. Since the backend's save_schema does a
    // full replace (not a merge) of the schema JSON, this second call
    // would silently overwrite — and strip — the correct relationKind the
    // first call had just written. Skipping entirely for relation fields.
    if ((draft.type as string) === "relation") {
      return;
    }

    try {
      let rawFields: Record<string, DomainFieldCore>;
      if (domainInNewDomains) {
        rawFields = { ...domainInNewDomains.fields };
      } else {
        rawFields = { ...(extra.extraFields[domainName] ?? {}) } as Record<string, DomainFieldCore>;
      }
      if (isRename) delete rawFields[oldName];
      // ✅ relation fields never become columns in the parent table —
      // they're handled via the child FK or the junction table instead.
      if ((draft.type as string) === "relation") {
        delete rawFields[newName];
      } else {
        rawFields[newName] = updatedField;
      }

      const updatedUIHints = { ...(liveSchemas.uiHints ?? {}) };
      if (isRename && updatedUIHints[oldPath]) { updatedUIHints[newPath] = updatedUIHints[oldPath]; delete updatedUIHints[oldPath]; }
      if (Object.values(uiHint).some((v) => v !== undefined)) updatedUIHints[newPath] = uiHint;

      // The full save below only ADDS columns, so a rename or type change
      // has to be applied to the existing column first — otherwise the old
      // column (and its data) is left behind next to a new empty one.
      if (lastBackendDomainNames.current.has(domainName)) {
        const oldType = (liveSchemas.domains[domainName]?.fields as any)?.[oldName]?.type;
        const typeChanged = !!oldType && oldType !== updatedField.type;
        if (isRename || typeChanged) {
          await apiUpdateField(domainName, oldName, {
            new_field_id: isRename ? newName : undefined,
            type:         typeChanged ? frontendTypeToBackend(updatedField.type as string) : undefined,
          });
        }
      }

      const req = domainToBackendRequest({
        registry: liveSchemas._layers?.validationRegistry ?? {},
        domainName, fields: rawFields as any, uiHints: updatedUIHints as any,
        rbacRules: extra.rbacRules as any, abacRules: extra.abacRules as any,
      });
      const res = await apiCreateDomain(req);
      if (res.status === "success") {
        const action = res.table_created ? "created" : "schema updated";
        const label  = isRename ? `"${oldName}" → "${newName}"` : `"${newName}"`;
        setBackendLoadStatus(`✅ Field ${label} saved — table "${domainName}" ${action} in ${dbLocation(res)}.`);
      } else {
        setBackendLoadStatus(`⚠️ Field saved locally, but backend error: ${res.message}`);
      }
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Field saved locally, but backend unreachable: ${err?.message}`);
    }
    setTimeout(() => setBackendLoadStatus(null), 5000);
  }

function handleDomainCreated(payload: CreateDomainPayload) {
    // Persist display-only relation markers
    for (const [fieldName, fieldDef] of Object.entries(payload.domain.fields)) {
      if (fieldDef.type === "relation" && fieldDef.relatedDomain && fieldName !== `${fieldDef.relatedDomain}Id`) {
        saveRelationMarker(payload.domain.name, fieldName, fieldDef);
      }
    }
    
    // ✅ Add relation back to parent domain if this was from a redirect
    if (pendingParentDomain && pendingDomainName && pendingRelationFieldName) {
      const relationField: DomainFieldCore = {
        type: "relation",
        relatedDomain: pendingDomainName,
      };
      setExtra((prev) => ({
        ...prev,
        extraFields: {
          ...prev.extraFields,
          [pendingParentDomain]: {
            ...(prev.extraFields[pendingParentDomain] ?? {}),
            [pendingRelationFieldName]: relationField,
          },
        },
      }));
      // 🔧 This relation field lives only on pendingParentDomain (e.g.
      // sampledomain.example → Example) — it's display-only, never a real
      // backend column, so nothing above actually persists it anywhere.
      // Without also saving it as a relation marker (same mechanism every
      // other relation-only field in this file relies on — see
      // saveRelationMarker above), the field only exists in the in-memory
      // `extra` state: it shows up immediately, but a refresh calls
      // handleLoadFromBackend, which rebuilds domains from the backend's
      // real schema and has no idea this field ever existed. The result
      // was exactly the reported bug — "Example" (a real table) survives
      // the refresh, but "example" on sampledomain silently disappears.
      saveRelationMarker(pendingParentDomain, pendingRelationFieldName, relationField);
      // Clear pending state
      setPendingDomainName(null);
      setPendingParentDomain(null);
      setPendingRelationFieldName(null);

      // The related domain that was missing is now created and linked
      // back onto pendingParentDomain above — jump back to whichever tab
      // the user was actually working in (e.g. "Domain Model") instead of
      // leaving them stranded on the Create Domain tab.
      if (returnTab) {
        setTab(returnTab);
        setReturnTab(null);
      }
    }
    
    // 🔥 NEW: Add pending FK to the new domain if it exists
    if (pendingFK && pendingFK.childDomain === payload.domain.name) {
      // pendingFK is only ever queued from the "is part of" (composition)
      // flow, so this FK is always relationKind: "integral". The `as const`
      // keeps the literal narrowed to "integral" instead of widening to a
      // plain string, which is required by DomainFieldCore.relationKind's
      // "integral" | "association" union.
      const updatedFields = {
        ...payload.domain.fields,
        [pendingFK.fkFieldName]: { type: "string" as FieldType, relationKind: "integral" as const },
      };
      // Update the domain with the FK field
      payload.domain.fields = updatedFields;
      
      // Also add to extraFields to ensure merge works
      setExtra((prev) => ({
        ...prev,
        extraFields: {
          ...prev.extraFields,
          [pendingFK.childDomain]: {
            ...(prev.extraFields[pendingFK.childDomain] ?? {}),
            [pendingFK.fkFieldName]: { type: "string", relationKind: "integral" as const },
          },
        },
      }));
      
      // Clear pending FK
      setPendingFK(null);
    }
    
    setExtra((prev) => {
      const nextPairs = new Set(prev.junctionPairs);
      const newJunctionDomains: DomainDefinition[] = [];

      for (const jd of payload.junctionDomains ?? []) {
        const parts  = jd.name.split("_");
        const pairKey = parts.sort().join("__");
        if (!nextPairs.has(pairKey)) {
          nextPairs.add(pairKey);
          newJunctionDomains.push(jd);
        }
      }
      const newRelatedDomains = (payload as any).relatedDomains ?? [];
      const allNew = [payload.domain, ...newRelatedDomains, ...newJunctionDomains];
       return {
        ...prev,
        newDomains: [
          ...prev.newDomains.filter((d) => !allNew.find((n: DomainDefinition) => n.name === d.name)),
          ...allNew,
        ],
        uiHints:    { ...prev.uiHints,   ...payload.uiHints   },
        rbacRules:  { ...prev.rbacRules, ...payload.rbacRules },
        abacRules:  { ...prev.abacRules, ...payload.abacRules },
        dbBackends: {
          ...prev.dbBackends,
          ...Object.fromEntries(allNew.map((d: DomainDefinition) => [d.name, payload.dbBackend])),
        },
        // Same reasoning as handleQuickCreateDomain/handleRichCreateDomain —
        // tag every domain created in this flow (including any related /
        // junction domains it pulled in) with whichever project is active
        // right now, so the Domain Model page's project filter can hide
        // them once you switch away.
        projectIds: currentProjectId
          ? {
              ...prev.projectIds,
              ...Object.fromEntries(allNew.map((d: DomainDefinition) => [d.name, currentProjectId])),
            }
          : prev.projectIds,
        moduleIds: currentModuleId
          ? {
              ...prev.moduleIds,
              ...Object.fromEntries(allNew.map((d: DomainDefinition) => [d.name, currentModuleId])),
            }
          : prev.moduleIds,
        versioned: { ...prev.versioned, [payload.domain.name]: payload.versioned },
        junctionPairs: nextPairs,
      };
    });

   
for (const [fieldName, fieldDef] of Object.entries(payload.domain.fields)) {
      const fieldUiHint = payload.uiHints[`${payload.domain.name}.${fieldName}`];
      const draftLabels = payload.fieldLabels?.[fieldName];

      apiSaveAttribute(
        payload.domain.name, fieldName,
        fieldUiHint?.label || fieldName, fieldDef.type,
      ).then(() => {
        if (!draftLabels) return;
        for (const lang of LANG_ORDER) {
          const text = draftLabels[lang]?.trim();
          if (!text) continue;
          apiSaveAttributeTranslation(payload.domain.name, fieldName, lang, text).catch(console.warn);
        }
      }).catch(console.warn);
    }
  }

  function handleAddUIHint(path: string, hint: FieldUIConfig) {
    setExtra((prev) => ({ ...prev, uiHints: { ...prev.uiHints, [path]: hint } }));
  }
  /**
   * Adds a brand-new named validation rule at runtime — "Create new rule"
   * in the field builder, for exactly the case where you need a
   * domain-specific rule (e.g. valid_patient_name) but that domain didn't
   * exist yet when src/validations/index.ts was last written. Persisted to
   * the backend's validation_rules table via apiSaveValidationRule — the
   * local extra.extraValidationRules update happens immediately (so the
   * new rule is usable right away in this session's picker) and the
   * backend save happens alongside it, so a reload picks it back up via
   * handleLoadValidationRulesFromBackend() below instead of losing it.
   */
  async function handleAddValidationRule(tag: string, rule: NamedValidationRule) {
    setExtra((prev) => ({ ...prev, extraValidationRules: { ...prev.extraValidationRules, [tag]: rule } }));
    try {
      const res = await apiSaveValidationRule(tag, rule as Omit<BackendValidationRule, "tag">);
      if (res.status !== "success") {
        setBackendLoadStatus(`⚠️ Rule "${tag}" saved locally, but backend: ${res.message}`);
        setTimeout(() => setBackendLoadStatus(null), 5000);
      }
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Rule "${tag}" saved locally, but backend unreachable: ${err?.message}`);
      setTimeout(() => setBackendLoadStatus(null), 5000);
    }
  }

  /** Converts one DB row (tag + rule fields flattened together) back into
   *  the { [tag]: NamedValidationRule } shape the rest of the app expects —
   *  the inverse of what apiSaveValidationRule sends. */
  function backendRuleToNamed(row: BackendValidationRule): NamedValidationRule {
    const { tag, ...rest } = row;
    return rest as NamedValidationRule;
  }

  /** GET /datastore/validation-rules on mount — loads every rule stored in
   *  the DB and merges it into extra.extraValidationRules, the same layer
   *  "Create new rule" writes into. This is what makes a rule created via
   *  the field builder survive a reload, instead of only living in this
   *  session's React state. */
  async function handleLoadValidationRulesFromBackend() {
    try {
      const res = await apiListValidationRules();
      if (res.status !== "success" || !res.rules?.length) return;
      setExtra((prev) => {
        const next = { ...prev.extraValidationRules };
        for (const row of res.rules) next[row.tag] = backendRuleToNamed(row);
        return { ...prev, extraValidationRules: next };
      });
    } catch (err: any) {
      console.warn("Could not load validation rules from backend:", err?.message);
    }
  }
  function handleRemoveUIHint(path: string) {
    setExtra((prev) => { const n = { ...prev.uiHints }; delete n[path]; return { ...prev, uiHints: n }; });
  }
  function handleAddRBAC(path: string, rule: RBACFieldRule) {
    setExtra((prev) => ({ ...prev, rbacRules: { ...prev.rbacRules, [path]: rule } }));
  }
  function handleRemoveRBAC(path: string) {
    setExtra((prev) => { const n = { ...prev.rbacRules }; delete n[path]; return { ...prev, rbacRules: n }; });
  }
  function handleAddABAC(path: string, rule: ABACFieldRule) {
    setExtra((prev) => ({ ...prev, abacRules: { ...prev.abacRules, [path]: rule } }));
  }
  function handleRemoveABAC(path: string) {
    setExtra((prev) => { const n = { ...prev.abacRules }; delete n[path]; return { ...prev, abacRules: n }; });
  }
function handleViewConfig(domainName: string, cfg: DomainViewConfig) {
    setExtra((prev) => ({ ...prev, viewConfigs: { ...prev.viewConfigs, [domainName]: cfg } }));
  }

  async function handleSaveTranslation(domainName: string, fieldName: string, lang: "en" | "ta" | "ar", text: string) {
    try {
      await apiSaveAttributeTranslation(domainName, fieldName, lang, text);
      setBackendLoadStatus(`✅ Translation saved for "${domainName}.${fieldName}" [${lang.toUpperCase()}]`);
    } catch (err: any) {
      setBackendLoadStatus(`⚠️ Translation save failed: ${err?.message}`);
    }
    setTimeout(() => setBackendLoadStatus(null), 3000);
  }

  // ── Edit / delete domain models and their attributes ───────────────────

  /** Drop every trace of a domain (or a renamed-away name) from local state. */
  function purgeDomainLocally(name: string) {
    const prefix = `${name}.`;
    const dropKeys = <T,>(rec: Record<string, T>) =>
      Object.fromEntries(Object.entries(rec).filter(([k]) => k !== name && !k.startsWith(prefix)));
    setExtra((prev) => ({
      ...prev,
      newDomains:  prev.newDomains.filter((d) => d.name !== name),
      extraFields: dropKeys(prev.extraFields),
      uiHints:     dropKeys(prev.uiHints),
      rbacRules:   dropKeys(prev.rbacRules),
      abacRules:   dropKeys(prev.abacRules),
      viewConfigs: dropKeys(prev.viewConfigs),
      dbBackends:  dropKeys(prev.dbBackends),
      versioned:   dropKeys(prev.versioned),
      projectIds:  dropKeys(prev.projectIds),
      moduleIds:   dropKeys(prev.moduleIds),
    }));
    lastBackendDomainNames.current.delete(name);
  }

  function flash(msg: string, ms = 4000) {
    setBackendLoadStatus(msg);
    setTimeout(() => setBackendLoadStatus(null), ms);
  }

  async function handleDeleteDomain(domainName: string) {
    try {
      if (lastBackendDomainNames.current.has(domainName)) {
        await apiDeleteDomain(domainName);
      }
      purgeDomainLocally(domainName);
      flash(`✅ Domain model "${domainName}" deleted.`);
    } catch (err: any) {
      flash(`❌ Could not delete "${domainName}": ${err?.message ?? String(err)}`, 6000);
    }
  }

  async function handleRenameDomain(oldName: string, newName: string) {
    const next = newName.trim();
    if (!next || next === oldName) return;
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(next)) {
      flash("⚠️ Domain names can only use letters, digits and underscores, and can't start with a digit.", 6000);
      return;
    }
    if (liveSchemas.domains[next]) {
      flash(`⚠️ A domain model named "${next}" already exists.`, 5000);
      return;
    }
    try {
      if (lastBackendDomainNames.current.has(oldName)) {
        await apiUpdateDomain(oldName, { new_table_name: next });
        purgeDomainLocally(oldName);
        await handleLoadFromBackend();
      } else {
        // Not saved yet — rename in local state only.
        const oldPrefix = `${oldName}.`;
        const rekey = <T,>(rec: Record<string, T>) =>
          Object.fromEntries(Object.entries(rec).map(([k, v]) => [
            k === oldName ? next : k.startsWith(oldPrefix) ? `${next}.${k.slice(oldPrefix.length)}` : k, v,
          ]));
        setExtra((prev) => ({
          ...prev,
          newDomains:  prev.newDomains.map((d) => (d.name === oldName ? { ...d, name: next } : d)),
          extraFields: rekey(prev.extraFields),
          uiHints:     rekey(prev.uiHints),
          rbacRules:   rekey(prev.rbacRules),
          abacRules:   rekey(prev.abacRules),
          viewConfigs: rekey(prev.viewConfigs),
          dbBackends:  rekey(prev.dbBackends),
          versioned:   rekey(prev.versioned),
          projectIds:  rekey(prev.projectIds),
          moduleIds:   rekey(prev.moduleIds),
        }));
      }
      flash(`✅ Renamed "${oldName}" → "${next}".`);
    } catch (err: any) {
      flash(`❌ Could not rename "${oldName}": ${err?.message ?? String(err)}`, 6000);
    }
  }

  async function handleDeleteField(domainName: string, fieldName: string) {
    try {
      if (lastBackendDomainNames.current.has(domainName)) {
        try {
          await apiDeleteField(domainName, fieldName);
        } catch (err: any) {
          // Display-only relation markers (e.g. an association field like
          // "service") have no column in the backend, so it answers 404
          // "Field ... not found". Nothing to drop there — just clean up locally.
          const msg = String(err?.message ?? "");
          const isMissingOnBackend = msg.includes("API 404") || /not found in/i.test(msg);
          if (!isMissingOnBackend) throw err;
        }
      }
      // Stop the saved marker from being re-hydrated on the next reload.
      removeRelationMarker(domainName, fieldName);
      const path = `${domainName}.${fieldName}`;
      setExtra((prev) => {
        const without = <T,>(rec: Record<string, T>) => {
          const c = { ...rec }; delete c[path]; return c;
        };
        const extraFields = { ...prev.extraFields };
        if (extraFields[domainName]) {
          const f = { ...extraFields[domainName] }; delete f[fieldName]; extraFields[domainName] = f;
        }
        return {
          ...prev,
          newDomains: prev.newDomains.map((d) => {
            if (d.name !== domainName) return d;
            const fields = { ...d.fields }; delete fields[fieldName];
            return { ...d, fields };
          }),
          extraFields,
          uiHints:   without(prev.uiHints),
          rbacRules: without(prev.rbacRules),
          abacRules: without(prev.abacRules),
        };
      });
      flash(`✅ Field "${fieldName}" deleted from "${domainName}".`);
    } catch (err: any) {
      flash(`❌ Could not delete "${fieldName}": ${err?.message ?? String(err)}`, 6000);
    }
  }

  async function handleSaveDomainToBackend(domainName: string) {
    const domainDef = liveSchemas.domains[domainName];
    if (!domainDef) return;
    try {
      const req = domainToBackendRequest({
        registry: liveSchemas._layers?.validationRegistry ?? {},
        domainName, fields: domainDef.fields as any, uiHints: liveSchemas.uiHints as any,
        rbacRules: extra.rbacRules as any, abacRules: extra.abacRules as any,
      });
      const res = await apiCreateDomain(req);
      if (res.status === "success") {
        const action  = res.table_created ? "created" : "already existed";
        const loc     = dbLocation(res);
        const nFields = res.total_fields ?? Object.keys(domainDef.fields).length;
        setBackendLoadStatus(`✅ Table "${domainName}" ${action} in ${loc} — ${nFields} field(s).`);
      } else {
        setBackendLoadStatus(`❌ Backend error: ${res.message}`);
      }
      setTimeout(() => setBackendLoadStatus(null), 4000);
    } catch (err: any) {
      setBackendLoadStatus(`❌ Network error: ${err?.message ?? String(err)}`);
      setTimeout(() => setBackendLoadStatus(null), 5000);
    }
  }

  async function handleLoadFromBackend() {
    try {
      const res = await apiListSchemas();
      if (res.status !== "success" || !res.schemas?.length) {
        // The current filter/project scope has no domain models — clear
        // out anything left over from the previous scope so switching to
        // an empty project actually shows an empty list instead of
        // leaving the last-fetched project's domains on screen.
        if (lastBackendDomainNames.current.size > 0) {
          setExtra((prev) => ({
            ...prev,
            newDomains: prev.newDomains.filter((d) => !lastBackendDomainNames.current.has(d.name)),
          }));
        }
        lastBackendDomainNames.current = new Set();
        setBackendLoadStatus("ℹ️ No schemas found in backend.");
        setTimeout(() => setBackendLoadStatus(null), 3000);
        return;
      }
      let count = 0;
      const freshNames = new Set<string>();
      setExtra((prev) => {
        let next = { ...prev };

        // Drop anything that was backend-sourced under the *previous*
        // load (e.g. the previously-selected project filter) but isn't
        // present in this response — otherwise it just lingers in
        // newDomains forever, since the per-entry merge below only ever
        // adds/replaces by name and never removes. Domains the user
        // created locally and hasn't saved yet (never part of
        // lastBackendDomainNames) are left untouched.
        if (lastBackendDomainNames.current.size > 0) {
          next.newDomains = next.newDomains.filter(
            (d) => !lastBackendDomainNames.current.has(d.name),
          );
        }

        for (const entry of res.schemas as unknown as BackendSchemaEntry[]) {
          const converted = backendSchemaToFrontend(entry);
          count++;
          freshNames.add(converted.domainName);
          const domainDef: DomainDefinition = {
            name: converted.domainName,
            fields: Object.fromEntries(
              Object.entries(converted.fields).map(([k, v]) => [k, {
                type: v.type as FieldType,
                default: v.default,
                datasource: v.datasource,
                relationKind: (v as any).relationKind,
                // relatedDomain and cardinality were both missing from this
                // whitelist — every relation field's related domain and
                // every list field's cardinality silently reverted to
                // empty/"one" on every single load-from-backend, even
                // after backendSchemaToFrontend() (and the underlying
                // domainToBackendRequest write) were fixed to actually
                // carry them. This is the same class of bug that hit
                // relationKind/cardinality earlier in buildSchemas() —
                // just one more copy of the same whitelist, in a
                // different function.
                relatedDomain: (v as any).relatedDomain,
                relatedDomains: (v as any).relatedDomains,
                cardinality: (v as any).cardinality,
                // Same gap, one more field: validationRefs (the tag
                // names, e.g. ["required-name"]) was never carried
                // through here either. Even with backendSchemaToFrontend
                // now reading it out of the raw backend response, this
                // whitelist would still have silently dropped it right
                // here on the way into domainDef.fields — the actual
                // enforceable rules were being saved (they run fine in a
                // live form), but the TAG IDENTITY was lost on every
                // reload, which is what the Domain Model tab's
                // "Validation Refs" column and the Export tab's
                // per-category Validations JSON both key off.
                validationRefs: (v as any).validationRefs,
              }])
            ),
          };
          const dbBackend = (entry as any).db_backend ?? "postgresql";
          const entryProjectId = (entry as any).project_id ?? null;
          const entryModuleId  = (entry as any).module_id ?? null;
          next = {
            ...next,
            newDomains: [...next.newDomains.filter((d) => d.name !== converted.domainName), domainDef],
            uiHints:    { ...next.uiHints,   ...converted.uiHints   },
            rbacRules:  { ...next.rbacRules, ...converted.rbacRules },
            abacRules:  { ...next.abacRules, ...converted.abacRules },
            dbBackends: { ...next.dbBackends, [converted.domainName]: dbBackend },
            projectIds: entryProjectId
              ? { ...next.projectIds, [converted.domainName]: entryProjectId }
              : next.projectIds,
            moduleIds: entryModuleId
              ? { ...next.moduleIds, [converted.domainName]: entryModuleId }
              : next.moduleIds,
          };
        }
        return next;
      });
      lastBackendDomainNames.current = freshNames;
      // Re-merge display-only relation markers that the backend has no
      // record of (e.g. clinic.branch) — otherwise they'd vanish here since
      // this whole function just overwrote newDomains with backend truth.
      const savedMarkers = loadRelationMarkers();
      if (Object.keys(savedMarkers).length > 0) {
        setExtra((prev) => {
          const nextExtraFields = { ...prev.extraFields };
          for (const [domName, markerFields] of Object.entries(savedMarkers)) {
            // Only rehydrate markers for domains that actually exist —
            // avoids resurrecting stale markers for deleted/renamed domains.
            const domainKnown =
              prev.newDomains.some((d) => d.name === domName) ||
              Object.keys(nextExtraFields).includes(domName);
            if (!domainKnown) continue;
            nextExtraFields[domName] = { ...(nextExtraFields[domName] ?? {}), ...markerFields };
          }
          return { ...prev, extraFields: nextExtraFields };
        });
      }

      setBackendLoadStatus(`✅ Loaded ${count} schema(s) from backend.`);
      setTimeout(() => setBackendLoadStatus(null), 4000);
    } catch (err: any) {
      setBackendLoadStatus(`❌ Load failed: ${err?.message ?? String(err)}`);
      setTimeout(() => setBackendLoadStatus(null), 5000);
    }
  }

  useEffect(() => {
    if (didAutoLoad.current) return;
    didAutoLoad.current = true;
    handleLoadFromBackend();
    handleLoadValidationRulesFromBackend();
  }, []);

  // Re-load the domain-model list whenever the selected project or module
  // changes (ProjectFilter / ModuleFilter in App.tsx) — skips the very first render, since the mount
  // effect above already loads with whatever project was selected on load.
  const skipInitialProjectReload = useRef(true);
  useEffect(() => {
    if (skipInitialProjectReload.current) {
      skipInitialProjectReload.current = false;
      return;
    }
    handleLoadFromBackend();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProjectId, currentModuleId]);

  return (
    <div className="si-root">

      <ImportDomainModelModal
        open={showImportModal}
        onClose={() => setShowImportModal(false)}
        onConfirm={handleImportDomainModelJson}
      />

      {backendLoadStatus && (
        <div className={`si-toast ${backendLoadStatus.startsWith("✅") ? "si-toast--ok" : backendLoadStatus.startsWith("ℹ️") ? "si-toast--info" : "si-toast--err"}`}>
          {backendLoadStatus}
        </div>
      )}

{tab === "domain" && (
        <DomainModelTab
          schemas={visibleSchemas}
          viewConfigs={extra.viewConfigs}
          dbBackends={extra.dbBackends}
          versioned={extra.versioned}
          projectIds={extra.projectIds}
          moduleIds={extra.moduleIds}
          focusDomain={focusDomain}
         junctionDomains={new Set(
  Array.from(extra.junctionPairs).flatMap((pairKey) => {
    const parts = pairKey.split("__");
    const name1 = `${parts[0]}_${parts[1]}`;
    const name2 = `${parts[1]}_${parts[0]}`;
    return [name1, name2].filter((n) => n in visibleSchemas.domains);
  })
)}
          onAddField={handleAddFieldToExisting}
          onEditField={handleEditField}
          onDeleteField={handleDeleteField}
          onDeleteDomain={handleDeleteDomain}
          onRenameDomain={handleRenameDomain}
          onViewConfig={handleViewConfig}
          onSaveBackend={handleSaveDomainToBackend}
          onQuickCreateDomain={handleQuickCreateDomain}
          onRichCreateDomain={handleRichCreateDomain}
          onRedirectToCreate={handleRedirectToCreate}
          onGoToCreateDomain={() => setTab("create")}
          onAddValidationRule={handleAddValidationRule}
          availableRoles={availableRoles}
          permissions={permissions}
          onChangePermissions={handleChangePermissions}
          onSavePermissions={handleSavePermissions}
          onLoadPermissions={handleLoadPermissions}
        />
      )}
      {tab === "ui" && (
        <UIConfigTab schemas={liveSchemas} onAdd={handleAddUIHint} onRemove={handleRemoveUIHint} extraHints={extra.uiHints} />
      )}
      {tab === "validations" && <ValidationsTab schemas={liveSchemas} />}
      {tab === "access" && (
        <AccessTab
          schemas={liveSchemas}
          onAddRBAC={handleAddRBAC} onRemoveRBAC={handleRemoveRBAC}
          onAddABAC={handleAddABAC} onRemoveABAC={handleRemoveABAC}
          extraRBACKeys={new Set(Object.keys(extra.rbacRules))}
          extraABACKeys={new Set(Object.keys(extra.abacRules))}
        />
      )}
      {/* Kept permanently mounted (instead of `{tab === "create" && ...}`)
          and just hidden with CSS when another tab is active. CreateDomainTab
          holds its in-progress "paused domain" stack (drafts/draftOrder) as
          local state — e.g. when you're building "Grade", add a relation to
          a not-yet-existing "Designation", and get switched over to build
          Designation first. Unmounting on every tab switch wiped that whole
          stack out, so navigating away (even briefly, even automatically)
          lost the paused "Grade" draft with no way to get it back. Staying
          mounted means that in-progress work survives regardless of which
          tab is showing. */}
      <div style={{ display: tab === "create" ? "block" : "none" }}>
        <CreateDomainTab
          onAdd={handleDomainCreated}
          registry={liveSchemas._layers?.validationRegistry ?? {}}
          domainNames={liveDomainNames}
          onQuickCreateDomain={handleQuickCreateDomain}
          onRichCreateDomain={handleRichCreateDomain}
          schemas={liveSchemas}
          initialDomainName={pendingDomainName || undefined}
          onRedirectToCreate={handleRedirectToCreate}
          pendingFK={pendingFK}
          onAddValidationRule={handleAddValidationRule}
          onGoToValidations={() => setTab("validations")}
        />
      </div>
      {tab === "data" && <DataTab schemas={liveSchemas} dbBackends={extra.dbBackends} />}
      {tab === "translations" && <TranslationsTab schemas={liveSchemas} onSave={handleSaveTranslation} />}
      {tab === "export" && <ExportJsonTab schemas={liveSchemas} projectIds={extra.projectIds} moduleIds={extra.moduleIds} />}

  
    </div>
  );
});