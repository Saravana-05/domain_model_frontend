import React, { useEffect, useState } from "react";
import StorageIcon             from "@mui/icons-material/Storage";
import PaletteOutlinedIcon     from "@mui/icons-material/PaletteOutlined";
import CheckCircleOutlinedIcon from "@mui/icons-material/CheckCircleOutlined";
import type { AllSchemas } from "../../schema/types";
import { Badge, CopyBlock } from "./helpers";
import { buildDomainModelJson, buildProjectStructureJson, buildUiConfigJson, buildValidationsJsonSplit, type ExportedDomainAccess } from "./exportJson";
import { loadDomainAccess } from "./accessLoader";
import { useProjectStore } from "../../store/projectStore";
import { apiListAllModules, type BackendModule } from "../../api/moduleApi";

interface ExportJsonTabProps {
  schemas: AllSchemas;
  /** domainName → project_id / module_id, so each domain lands under the right Project → Module. */
  projectIds?: Record<string, string>;
  moduleIds?: Record<string, string>;
}

export function ExportJsonTab({ schemas, projectIds = {}, moduleIds = {} }: ExportJsonTabProps) {
  // Projects come from the shared store; modules are fetched for ALL projects
  // (the store only holds the current project's) so the export is complete.
  const projects = useProjectStore((s) => s.projects);
  const treeVersion = useProjectStore((s) => s.treeVersion);
  const [allModules, setAllModules] = useState<BackendModule[]>([]);
  useEffect(() => {
    let cancelled = false;
    apiListAllModules()
      .then((res) => { if (!cancelled) setAllModules(res.data ?? []); })
      .catch(() => { if (!cancelled) setAllModules([]); });
    return () => { cancelled = true; };
  }, [treeVersion]);

  // Domain-level RBAC (role → actions) + ABAC rules live in the backend, so
  // they're fetched here and embedded into each domain's JSON as `access`.
  const [domainAccess, setDomainAccess] = useState<Record<string, ExportedDomainAccess>>({});
  const [accessStatus, setAccessStatus] = useState<"loading" | "done">("loading");
  const domainKey = Object.keys(schemas.domains).sort().join("|");
  useEffect(() => {
    let cancelled = false;
    setAccessStatus("loading");
    loadDomainAccess(Object.keys(schemas.domains)).then((a) => {
      if (!cancelled) { setDomainAccess(a); setAccessStatus("done"); }
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [domainKey]);

  const domainModelJson = buildDomainModelJson(schemas, domainAccess);
  const structureJson = buildProjectStructureJson(
    schemas,
    { projects, modules: allModules, projectIds, moduleIds },
    domainAccess,
  );
  const uiConfigJson = buildUiConfigJson(schemas);
  const { common: commonValidations, byCategory: validationsByCategory } = buildValidationsJsonSplit(schemas);
  const realAttrCount = domainModelJson.domain_models.reduce(
    (sum, d) => sum + d.attributes.filter(a => !(a.related_domain_model && "contains" in a.related_domain_model)).length, 0
  );
  const synthesizedCount = domainModelJson.domain_models.reduce(
    (sum, d) => sum + d.attributes.filter(a => a.related_domain_model && "contains" in a.related_domain_model).length, 0
  );

  return (
    <div className="si-domains">
      <div className="si-card">
        <div className="si-card-header">
          <StorageIcon sx={{ fontSize: 16, color: "#7e22ce" }} />
          <span className="si-domain-name">Project → Module → Domain Model</span>
          <span className="si-field-count">
            {structureJson.projects.length} project(s) — {allModules.length} module(s) — {domainModelJson.domain_models.length} domain model(s) — {realAttrCount} real attribute(s)
            {synthesizedCount > 0 ? ` + ${synthesizedCount} synthesized reverse attribute(s)` : ""} — RBAC/ABAC embedded per attribute under "access"; no UI/label data, no duplication
            {accessStatus === "loading" ? " — loading RBAC/ABAC…" : ` — RBAC/ABAC embedded for ${Object.keys(domainAccess).length} domain(s)`}
          </span>
        </div>
        <div style={{ padding: "0 16px 16px 16px" }}>
          <CopyBlock title="Project / module / domain model JSON" code={JSON.stringify(structureJson, null, 2)} />
        </div>
      </div>

      <div className="si-card">
        <div className="si-card-header">
          <PaletteOutlinedIcon sx={{ fontSize: 16, color: "#0f766e" }} />
          <span className="si-domain-name">UI Config</span>
          <span className="si-field-count">{Object.keys(uiConfigJson).length} attribute(s) with UI settings — keyed "domain.attribute_id"</span>
        </div>
        <div style={{ padding: "0 16px 16px 16px" }}>
          <CopyBlock title="UI config JSON" code={JSON.stringify(uiConfigJson, null, 2)} />
        </div>
      </div>

      {/* Common validations — one shared block, exported ONCE regardless
          of how many domains reference any given rule. Split out from the
          per-category blocks below specifically so a rule like
          "required-name" never gets duplicated across clinic's AND
          doctor's AND every other domain's JSON just because they all
          happen to use it. */}
      <div className="si-card">
        <div className="si-card-header">
          <CheckCircleOutlinedIcon sx={{ fontSize: 16, color: "#334155" }} />
          <span className="si-domain-name">Common — Validations</span>
          <span className="si-field-count">{commonValidations.validations.length} rule(s) — reusable across any domain</span>
        </div>
        <div style={{ padding: "0 16px 16px 16px" }}>
          <CopyBlock title="Common validations JSON" code={JSON.stringify(commonValidations, null, 2)} />
        </div>
      </div>

      {/* One card per category (domain-specific rules only) — grouped by
          the rule's own `category`, not by which domain's fields happen
          to reference it, so nothing here overlaps with the Common block
          above. A category only appears here once it has at least one
          rule — there's no forced empty card for every domain anymore. */}
      {Object.entries(validationsByCategory).map(([category, categoryValidations]) => {
        const cardinalityCount = categoryValidations.validations.filter(v => v.kind === "cardinality").length;
        return (
          <div className="si-card" key={category}>
            <div className="si-card-header">
              <CheckCircleOutlinedIcon sx={{ fontSize: 16, color: "#92400e" }} />
              <span className="si-domain-name">{category} — Validations</span>
              <span className="si-field-count">
                {categoryValidations.validations.length} rule(s)
                {cardinalityCount > 0 ? ` — ${cardinalityCount} "cardinality" (authored, not yet enforced)` : ""}
              </span>
            </div>
            <div style={{ padding: "0 16px 16px 16px" }}>
              <CopyBlock title={`${category} validations JSON`} code={JSON.stringify(categoryValidations, null, 2)} />
            </div>
          </div>
        );
      })}

      <div className="si-tip">
        <span>
          💡 Domain models are nested the way the sidebar shows them: <code>projects[]</code> → <code>modules[]</code> → <code>domain_models[]</code>.
          A project's own <code>domain_models</code> holds the ones in no module, and a top-level <code>domain_models</code> (only present when needed)
          holds the ones in no project. Every attribute always carries <code>cardinality</code> (<code>"one"</code> by default, <code>"many"</code> when List is
          checked). <code>related_domain_model</code> only appears on actual relation attributes, and its key names the
          relationship directly instead of a generic role: <code>linked_with</code> for an association (either direction),
          <code>part_of</code> on the real stored FK (this domain is the child, e.g. <code>branch.clinic_id</code>), or
          <code>contains</code> on the synthesized reverse attribute on the parent domain (e.g. <code>clinic.branches</code> —
          this one has no real backing column, it's generated purely to make the relationship visible from the parent's own
          side). Domain-level access control (from the Access Control screen) is embedded on each domain under <code>access</code>:
          <code>access.rbac</code> maps a role to the actions it may perform (<code>create</code> / <code>view</code> / <code>edit</code> / <code>delete</code>) and
          <code>access.abac</code> only holds ABAC rules that apply to every field. ABAC rules that target specific attributes
          sit under those attributes' own <code>access.abac</code>. Field-level access control lives inline on the attribute: <code>access.rbac</code> holds the role arrays
          (<code>visible</code> / <code>read</code> / <code>write</code> / <code>disabled</code>) and <code>access.abac</code> holds the
          runtime expressions — both are omitted when the attribute has none, so there is no separate RBAC or ABAC JSON to export.
          UI Config is a completely separate structure, referenced by the same <code>"domain.attribute_id"</code>{" "}
          key — nothing is duplicated between the two. Validations are split by <code>category</code>, not by which domain's
          fields reference a tag — a rule with <code>category: "common"</code> exports exactly once in the shared Common
          block no matter how many domains use it, while a domain-specific category (e.g. <code>"clinic"</code>) gets its own
          block with nothing overlapping the common one. <code>kind: "cardinality"</code> rules are exported correctly but
          aren't enforced by any field yet — there's no relation-count validation engine wired up to actually run them.
        </span>
      </div>
    </div>
  );
}